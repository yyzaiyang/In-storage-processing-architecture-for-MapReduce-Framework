#define _CRTDBG_MAP_ALLOC
#define _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES 1

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <stdbool.h>
#include <crtdbg.h>
#include <math.h>

#include "main.h"
#include "host.h"
#include "core.h"
#include "ssd.h"
#include "transfer.h"
#include "initial.h"

extern unsigned long long TIMETICK;
extern int input_count;

struct name_node* namenode_operation(struct name_node* namenode)
{
	namenode->head = priority_assignment(namenode->head, input_count);  //Priority Assignment
	namenode->head = Dispatcher(namenode->head);  //Dispatcher
	data_assignment(namenode->head);  //transfer data to node
	if (MODE->structure == WTE)
	{
		initial_ac(Namenode);
		namenode->ac = admission_control_estimation(namenode->ac, input_count);  //Admission Control
	}
	return namenode;
}

struct Input* Dispatcher(struct Input* input)
{
	struct Input* temp;
	temp = input;
	struct sub_task* sub;

	while (temp != NULL)
	{
		sub = temp->sub;
		while (sub != NULL)
		{
			if (sub->rack_id == NOSET && sub->phase == MAP)
			{
				if (MODE->structure == CPU_CENTRIC || MODE->structure == ISC_map || MODE->structure == ISC_both)
				{
					sub->rack_id = DATA->rack[sub->req_no][0];
					sub->node_id = DATA->node[sub->req_no][0];
				}
				else if (MODE->structure == WTE)
				{
					map_dispatcher(&sub->rack_id, &sub->node_id, sub, temp);
					//printf("req: %d rack: %d node: %d\n", sub->req_no, sub->rack_id, sub->node_id);
				}
				else printf("NO MAP DISPATCHER MATCH!\n");
			}
			else if (sub->rack_id == NOSET && sub->phase == REDUCE)
			{
				if (MODE->structure == CPU_CENTRIC || MODE->structure == ISC_map || MODE->structure == ISC_both)
				{
					sub->rack_id = DATA->rack[sub->req_no][0];
					sub->node_id = DATA->node[sub->req_no][0];
				}
				else if (MODE->structure == WTE)
				{
					reduce_dispatcher(&sub->rack_id, &sub->node_id, sub, temp);
				}
				else printf("NO REDUCE DISPATCHER MATCH!\n");
			}
			sub = sub->next;
		}
		temp = temp->next;
	}
	return input;
}

void reduce_dispatcher(int* rack_id, int* node_id, struct sub_task* sub, struct Input* input)
{
	struct rack_info* rack_info;
	struct node_info* node_info;
	struct job_tracker* job_t;
	
	int i, j, R_choice = NOSET, N_choice = NOSET;
	unsigned long long waiting_time = 1000000000, task_time = 0, task_time_compare = 0;
	int dep_compare = 0, dep = 0;
	long long total_task = 0;

	if (sub->App_type != TERASORT && sub->App_type != DFSIO)
	{
		for (i = 0; i < TOTAL_RACK; i++)
		{
			rack_info = Namenode->info[i];
			for (j = 0; j < TOTAL_NODE; j++)
			{
				dep_compare += rack_info->dep_req_no[sub->req_no][j];
			}
			
			if (dep_compare > dep)
			{
				dep = dep_compare;
				R_choice = i;
				total_task = Namenode->info[i]->total_task_in_rack;
			}
			else if (dep_compare == dep)
			{
				if (Namenode->info[i]->total_task_in_rack < total_task)
				{
					dep = dep_compare;
					R_choice = i;
					total_task = Namenode->info[i]->total_task_in_rack;
				}
			}
		}
		
		rack_info = Namenode->info[R_choice];
		for (i = 0; i < TOTAL_NODE; i++)
		{
			node_info = rack_info->info[i];
			task_time_compare = task_time_estimation(task_time_compare, sub, R_choice, i);
			if (node_info->waiting_time + task_time_compare < waiting_time)
			{
				waiting_time = node_info->waiting_time + task_time_compare;
				task_time = task_time_compare;
				N_choice = i;
			}
		}
	}
	else
	{
		for (i = 0; i < TOTAL_RACK; i++)
		{
			rack_info = Namenode->info[i];
			for (j = 0; j < TOTAL_NODE; j++)
			{
				node_info = rack_info->info[j];
				task_time_compare = task_time_estimation(task_time_compare, sub, i, j);//task time estimate

				if (node_info->waiting_time + task_time_compare < waiting_time)
				{
					waiting_time = node_info->waiting_time + task_time_compare;
					task_time = task_time_compare;
					R_choice = i;
					N_choice = j;
				}
			}
		}
	}
	
	rack_info = Namenode->info[R_choice];
	rack_info = info_update(rack_info, sub, task_time, R_choice, N_choice);  //update info
	*rack_id = R_choice;
	*node_id = N_choice;

}

void map_dispatcher(int* rack_id, int* node_id, struct sub_task* sub, struct Input* input)
{
	struct rack_info* rack_info;
	struct node_info* node_info;

	int i, j, R_choice = NOSET, N_choice = NOSET, locality_check = Remote;
	unsigned long long waiting_time = 1000000000, task_time = 0, task_time_compare = 0;
	/*printf("%lf\n", ceil((double)input->total_map_task / ((double)(TOTAL_RACK * TOTAL_NODE) - 0)));*/
	for (i = 0; i < TOTAL_RACK; i++)
	{
		rack_info = Namenode->info[i];
		for (j = 0; j < TOTAL_NODE; j++)
		{
			node_info = rack_info->info[j];
			task_time_compare = task_time_estimation(task_time_compare, sub, i, j);//task time estimate
			
			if (node_info->waiting_time + task_time_compare < waiting_time && node_info->total_map_task_in_node < ceil((double)node_info->total_map_task / ((double)(TOTAL_RACK * TOTAL_NODE)  -0  )))
			{
				waiting_time = node_info->waiting_time + task_time_compare;
				task_time = task_time_compare;
				R_choice = i;
				N_choice = j;
			}
		}
	}
	
	locality_check = locality_get(sub, R_choice, N_choice);  //add local or remote
	get_transfer(CLUSTER, locality_check, R_choice, sub->req_no, sub->priority, sub->rt_total, sub->dep_task_no, MAP);
	
	rack_info = Namenode->info[R_choice];
	rack_info = info_update(rack_info, sub, task_time, R_choice, N_choice);  //update info
	*rack_id = R_choice;
	*node_id = N_choice;
}

unsigned long long task_time_estimation(unsigned long long task_time, struct sub_task* sub, int R_choice, int N_choice)
{
	struct parameter* para;
	para = Namenode->rack[R_choice]->data_node[N_choice]->ssd->para;
	unsigned long long t_ssdr = 0, t_ssdw = 0, t_exe = 0, t_D = 0, t_gc = 0;
	int i, locality_check = Remote;
	long long multiple = pow(10, 3);

	if (sub->phase == MAP)
	{
		t_exe = MODE->map_time;
		if (sub->App_type == TERASORT || sub->App_type == GREP)
		{
			t_ssdr = (sub->size * para->page_MB * 122575) / para->channel;
			t_ssdw = (sub->size * para->page_MB * 302575) / para->channel;
		}
		else if (sub->App_type == WC)
		{
			t_ssdr = (sub->size * para->page_MB * 122575) / para->channel;
			t_ssdw = (ceil(sub->size * WCratio) * para->page_MB * 302575) / para->channel;
		}
		else if (sub->App_type == DFSIO)
		{
			t_ssdr = (sub->size * para->page_MB * 122575) / para->channel;
			t_ssdw = (ceil(sub->size * DFSIO) * para->page_MB * 302575) / para->channel;
		}
	}
	else if (sub->phase == REDUCE)
	{
		t_exe = MODE->reduce_time;
		if (sub->App_type == TERASORT || sub->App_type == GREP)
		{
			t_ssdr = (sub->size * para->page_MB * 122575) / para->channel;
			t_ssdw = (sub->size * para->page_MB * 302575) / para->channel;
		}
		else if (sub->App_type == WC)
		{
			t_ssdr = (ceil(sub->size * WCratio) * para->page_MB * 122575) / para->channel;
			t_ssdw = (ceil(sub->size * WCratio) * para->page_MB * 302575) / para->channel;
		}
		else if (sub->App_type == DFSIO)
		{
			t_ssdr = (ceil(sub->size * DFSIO) * para->page_MB * 122575) / para->channel;
			t_ssdw = (ceil(sub->size * DFSIO * DFSIO) * para->page_MB * 302575) / para->channel;
		}
	}

	//gc problem to be continue
	t_ssdr = t_ssdr / (multiple * multiple);
	t_ssdw = t_ssdw / (multiple * multiple);
	locality_check = locality_get(sub, R_choice, N_choice);  //locality check
	if (locality_check == Remote) t_D = ((double)sub->size / (double)TRANS->R_to_R) * multiple;
	else if (locality_check == Rack_local) t_D = ((double)sub->size / (double)TRANS->N_to_N) * multiple;
	
	task_time = t_ssdr + t_exe + t_ssdw + t_D + t_gc;
	return task_time;
}

int locality_get(struct sub_task* sub, int R_choice, int N_choice)
{
	int i, locality_level = Remote;
	for (i = 0; i < replica; i++)
	{
		if (R_choice == DATA->rack[sub->req_no][i])
		{
			if (N_choice == DATA->node[sub->req_no][i])
			{
				locality_level = Local;
			}
			else
			{
				if (locality_level > Rack_local) locality_level = Rack_local;
			}
		}
	}

	return locality_level;
}

struct rack_info* info_update(struct rack_info* info, struct sub_task* sub, unsigned long long task_time, int rack_id, int node_id)
{
	struct rack_info* temp;
	struct node_info* node_temp;
	struct parameter* para;

	unsigned long long blocking_time = 0, waiting_time = 0;
	unsigned long multiple_6 = pow(10, 6); // ns -> ms
	long long regain_size = 0;
	int remainder = 0, i;
	temp = info;
	node_temp = temp->info[node_id];
	para = Namenode->rack[rack_id]->data_node[node_id]->ssd->para;
	
	if (sub->phase == MAP)
	{
		temp->dep_req_no[sub->dep_task_no][node_id]++;
		
		node_temp->total_map_task_in_node++;
		if (sub->App_type == WC)
		{
			node_temp->gc_overprovision_estimation -= ceil(sub->size * WCratio) * para->page_MB;
			regain_size = ceil(sub->size * WCratio) * para->page_MB;
		}
		else if (sub->App_type == TERASORT || sub->App_type == GREP)
		{
			node_temp->gc_overprovision_estimation -= sub->size * para->page_MB;
			regain_size = sub->size * para->page_MB;
		}
		else if (sub->App_type == DFSIO)
		{
			node_temp->gc_overprovision_estimation -= ceil(sub->size * DFSIOratio) * para->page_MB;
			regain_size = ceil(sub->size * DFSIOratio) * para->page_MB;
		}
	}
	else if (sub->phase == REDUCE)
	{
		node_temp->total_red_task_in_ndoe++;
		if (sub->App_type == WC)
		{
			node_temp->gc_overprovision_estimation -= ceil(sub->size * WCratio) * para->page_MB;
			regain_size = ceil(sub->size * WCratio) * para->page_MB;
		}
		else if (sub->App_type == TERASORT || sub->App_type == GREP)
		{
			node_temp->gc_overprovision_estimation -= sub->size * para->page_MB;
			regain_size = sub->size * para->page_MB;
		}
		else if (sub->App_type == DFSIO)
		{
			node_temp->gc_overprovision_estimation -= ceil(sub->size * DFSIOratio * DFSIOratio) * para->page_MB;
			regain_size = ceil(sub->size * DFSIOratio * DFSIOratio) * para->page_MB;
		}
	}

	if (node_temp->gc_overprovision_estimation < node_temp->gc_threshold_estimation)
	{
		node_temp->gc_count++;
		node_temp->gc_overprovision_estimation += regain_size;
	}

	blocking_time = (((unsigned long long)block_size * para->page_MB * 302575) / para->channel) / multiple_6;
	remainder = node_temp->total_task_in_node % TOTAL_CORE;

	/*if (remainder == 0) node_temp->waiting_time_keep[remainder] += task_time;
	else node_temp->waiting_time_keep[TOTAL_CORE - remainder] += (task_time + (blocking_time * (TOTAL_CORE - (unsigned long long)remainder)));*/

	
	if (remainder == 0) node_temp->waiting_time += task_time;
	else node_temp->waiting_time += blocking_time;
	
	
	temp->total_task_in_rack++;
	node_temp->total_task_in_node++;
	
	/*if (node_temp->total_task_in_node % TOTAL_CORE == 0)
	{
		for (i = 0; i < TOTAL_CORE; i++)
		{
			if (node_temp->waiting_time_keep[i] > waiting_time) waiting_time = node_temp->waiting_time_keep[i];
		}
		node_temp->waiting_time += waiting_time;
	}*/
	//node_temp->waiting_time += task_time;
	return info;
}

struct Input* priority_assignment(struct Input* input, int app_count)
{
	struct Input* temp;
	struct sub_task* sub;
	long long read_size = 0, write_size = 0, load = 0, load_compare = 0, range = 0;
	
	int i;
	for (i = 1; i <= app_count; i++)
	{
		load = 0;
		temp = input;
		while (temp != NULL)
		{
			if (temp->App_type == TERASORT || temp->App_type == GREP)
			{
				read_size = temp->total_map_task * block_size + temp->total_reduce_task * block_size;
				write_size = read_size;
			}
			else if (temp->App_type == WC)
			{
				read_size = temp->total_map_task * block_size + temp->total_reduce_task * ceil(WCratio * block_size);
				write_size = temp->total_map_task * ceil(WCratio * block_size) + temp->total_reduce_task * ceil(WCratio * block_size);
			}
			else if (temp->App_type == DFSIO)
			{
				read_size = temp->total_map_task * block_size + temp->total_reduce_task * ceil(DFSIOratio * block_size);
				write_size = temp->total_map_task * ceil(DFSIOratio * block_size) + temp->total_reduce_task * ceil(DFSIOratio * DFSIOratio * block_size);;
			}
			load_compare = read_size + write_size;

			if (i == 1)
			{
				if (load_compare > load)
				{
					temp->priority = i;
					load = load_compare;
				}
			}
			else
			{
				if (load_compare > load && load_compare < range)
				{
					temp->priority = i;
					load = load_compare;
				}
			}
			temp = temp->next;
		}
		range = load;
	}

	temp = input;
	temp = key_in_prio(temp);
	
	return input;
}

struct Input* key_in_prio(struct Input* input)
{
	struct Input* temp;
	temp = input;
	struct sub_task* sub;

	while (temp != NULL)
	{
		sub = temp->sub;
		while(sub != NULL)
		{
			sub->priority = temp->priority;
			sub = sub->next;
		}
		temp = temp->next;
	}
}