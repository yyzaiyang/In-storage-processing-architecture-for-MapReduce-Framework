#pragma once

//#define DEBUG
#include "initial.h"

struct admission_control
{
	int App_no;
	int App_type;
	int prio;
	long long total_size;
	long long total_map_task;
	long long total_reduce_task;
	long long read_size;
	long long write_size;

	unsigned long long start;
	unsigned long long end;
	unsigned long long resp_time[(TOTAL_NODE * TOTAL_RACK) + 1];
	unsigned long long t_gc[(TOTAL_NODE * TOTAL_RACK) + 1];  
	unsigned long long read_resp[(TOTAL_NODE * TOTAL_RACK) + 1];
	unsigned long long write_resp[(TOTAL_NODE * TOTAL_RACK) + 1];

	double predicted_Read_SLO[(TOTAL_NODE * TOTAL_RACK) + 1];
	double predicted_Write_SLO[(TOTAL_NODE * TOTAL_RACK) + 1];

	long long MAP_time[(TOTAL_NODE * TOTAL_RACK) + 1];
	long long RED_time[(TOTAL_NODE * TOTAL_RACK) + 1];

	unsigned long long Map_per_task;
	unsigned long long Red_per_task;
	unsigned long long Mssd_r;
	unsigned long long Mssd_w;
	unsigned long long Rssd_r;
	unsigned long long Rssd_w;

	long long node_needed;

	struct admission_control* next;
};


int Activate_check(struct name_node* namenode);
struct name_node* fetch_tranfer(struct name_node* namenode);
int relation_check(struct task_queue* task, struct sub_task* sub, int* rack_id);
struct Input* conclude(struct Input* input);
void SLO_estimation(double* R_SLO, double* W_SLO, struct Input* input);
struct admission_control* admission_control_estimation(struct admission_control* ac, int total_app);