#pragma once

#define Local 0
#define Rack_local 1
#define Remote 2

#define pending 1
#define done 2

struct transfer
{
	unsigned long long N_to_N;  //node to node
	unsigned long long R_to_R;  //rack to rack

}*TRANS;

struct data_transfer_list
{
	int transfer_flag;  //2 = done, 1 = pending, 0 = IDLE
	int req_no;
	int dep_task_no;
	int App_type;
	int App_no;
	long long size;

	int rack_id;
	int node_id;
	int phase;

	unsigned long long data_in;  //time where data fetch to queue
	unsigned long long data_out;  //time where data complete transfer
	unsigned long long transfer_time;  //time where data needed for transfer

	struct data_transfer_list* next;
};

struct transfer_estimation_queue
{
	int req_no;
	int dep_task_no;
	int App_type;
	int App_no; 
	long long size;

	int rack_id;
	int node_id;
	int phase;

	unsigned long long data_in;  //time where data fetch to queue
	unsigned long long data_out;  //time where data complete transfer
	unsigned long long transfer_time;  //time where data needed for transfer
	unsigned long long delay_time;  //waiting time
};

struct transfer_cluster
{
	struct Rack_to_Rack* R_R;
	struct Node_to_Node* N_N[TOTAL_RACK];
}*CLUSTER;

struct Rack_to_Rack
{
	unsigned long long current_time;
	int queue[QUEUE_SIZE];
	int record_prio[QUEUE_SIZE];
	int record_dep_task[QUEUE_SIZE];
	int record_rt[QUEUE_SIZE];

	int stat;
	int current_req;

	int total_req;
	int count;

	struct transfer_estimation_queue* t_queue;
	struct data_transfer_list* list;
	struct data_transfer_list* current;
	struct data_transfer_list* prev;
};

struct Node_to_Node
{
	int rack_id;

	unsigned long long current_time;
	int queue[QUEUE_SIZE];
	int record_prio[QUEUE_SIZE];
	int record_dep_task[QUEUE_SIZE];
	int record_rt[QUEUE_SIZE];

	int stat;
	int current_req;

	int total_req;
	int count;

	struct transfer_estimation_queue* t_queue;
	struct data_transfer_list* list;
	struct data_transfer_list* current;
	struct data_transfer_list* prev;
};

void data_assignment(struct Input* input);
void data_to_node(struct data_node* node, int rack_id, int node_id, struct sub_task* sub);
void get_transfer(struct transfer_cluster* cluster, int relation, int rack_id, int req_no, int Prio, int rt_total, int dep_task, int phase);
void Add_local(struct Node_to_Node* N_N, int req_no, int Prio, int rt_total, int dep_task);
void Add_remote(struct Rack_to_Rack* R_R, int req_no, int Prio, int rt_total, int dep_task);
void transfer_process(struct transfer_cluster* cluster);
void transfer_sim_remote(struct Rack_to_Rack* R_R, struct Input* input);
struct transfer_estimation_queue* get_info_remote(struct transfer_estimation_queue* queue, struct sub_task* sub, struct Rack_to_Rack* R_R);
void remote_listing(struct Rack_to_Rack* R_R, struct transfer_estimation_queue* queue);
void transfer_sim_local(struct Node_to_Node* N_N, struct Input* input);
struct transfer_estimation_queue* get_info_local(struct transfer_estimation_queue* queue, struct sub_task* sub, struct Node_to_Node* N_N);
void local_listing(struct Node_to_Node* N_N, struct transfer_estimation_queue* queue);
struct name_node* transfer_timer(struct name_node* namenode);
struct name_node* transfer_ssd_preset(struct name_node* namenode);
struct Rack_to_Rack* remote_timer(struct Rack_to_Rack* R_R, struct name_node* namenode);
struct Node_to_Node* local_timer(struct Node_to_Node* N_N, struct name_node* namenode);
