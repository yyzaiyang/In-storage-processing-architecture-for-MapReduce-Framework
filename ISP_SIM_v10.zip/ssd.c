#define _CRTDBG_MAP_ALLOC
#define _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES 1

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <stdbool.h>
#include <crtdbg.h>
#include <math.h>

#include "main.h"
#include "host.h"
#include "core.h"
#include "ssd.h"
#include "transfer.h"
#include "initial.h"

extern unsigned long long TIMETICK;

void ssd_sim(struct data_node* node)
{
	struct ssd* ssd;
	ssd = node->ssd;
	struct waiting_queue* read, * write;
	read = ssd->read_q;
	write = ssd->write_q;
	int flag = TRUE;

	if (ssd->ssd_stat == IDLE)
	{
		if (write == NULL)
		{
			while (read != NULL)
			{
				if (flag == TRUE)
				{
					ssd->req_q = get_ssd_request(ssd->req_q, read);  //get req
					read->flag = TRUE;
					flag = FALSE;
					ssd->ssd_stat = BUSY;
				}
				read = read->next;
			}
		}
		else if (read == NULL)
		{
			while (write != NULL)
			{
				if (flag == TRUE)
				{
					ssd->req_q = get_ssd_request(ssd->req_q, write);  //get req
					write->flag = TRUE;
					flag = FALSE;
					ssd->ssd_stat = BUSY;
				}
				write = write->next;
			}
		}
		else if (write != NULL && read != NULL)
		{
			while (write != NULL)
			{
				if (flag == TRUE)
				{
					ssd->req_q = get_ssd_request(ssd->req_q, write);  //get req
					write->flag = TRUE;
					flag = FALSE;
					ssd->ssd_stat = BUSY;
				}
				write = write->next;
			}
		}
		ssd_process(ssd);  //ssd process
		ssd_set_time(ssd, node);  //set time
		clear_ssd_queue(ssd);  //clear queue -> waiting + req
	}
	
}

struct request_queue* get_ssd_request(struct request_queue* req, struct waiting_queue* queue)
{
	req = (struct request_queue*)malloc(sizeof(struct request_queue));
	
	req->App_no = queue->App_no;
	req->App_type = queue->App_type;
	req->ope = queue->ope;
	req->req_no = queue->req_no;
	req->req_size = queue->req_size;
	req->T_flag = queue->T_flag;
	req->phase = queue->phase;

	return req;
}

void ssd_process(struct ssd* ssd)
{
	unsigned long multiple = pow(10, 6); // ms -> ns
	unsigned long long process_time = 0;

	if (ssd->current_time < TIMETICK * multiple)
	{
		ssd->current_time = TIMETICK * multiple;
	}

	struct request_queue* req;
	struct parameter* para;
	req = ssd->req_q;
	para = ssd->para;

	unsigned long long Read_page = (7 * para->tWC) + para->tR + (para->sub_page * para->subpage_capacity * para->tRC);
	unsigned long long Write_page = (7 * para->tWC) + (para->sub_page * para->subpage_capacity * para->tRC) + para->tPROG;

	if (req != NULL)
	{
		if (req->T_flag == TRUE)
		{
			if (req->ope == WRITE)
			{
				if (req->phase == MAP)
				{
					process_time = (req->req_size * para->page_MB * Write_page) / para->channel;
				}
				else if (req->phase == REDUCE)
				{
					if (req->App_type == WC) process_time = (ceil(req->req_size * WCratio) * para->page_MB * Write_page) / para->channel;
					else if (req->App_type == TERASORT || req->App_type == GREP) process_time = (req->req_size * para->page_MB * Write_page) / para->channel;
					else if (req->App_type == DFSIO) process_time = (ceil(req->req_size * DFSIOratio) * para->page_MB * Write_page) / para->channel;
				}

				process_time = process_time / multiple;
				process_time = process_time * multiple;
				process_time = garbage_collection(ssd, process_time);  //gc check 

				req->response_time = ssd->current_time + process_time;
				ssd->current_time = req->response_time;
			}
		}
		else if(req->T_flag == FALSE)
		{
			if (req->ope == READ)
			{
				req->read_start = ssd->current_time;
				if (req->phase == MAP)
				{
					process_time = (req->req_size * para->page_MB * Read_page) / para->channel;
				}
				else if (req->phase == REDUCE)
				{
					if (req->App_type == WC) process_time = (ceil(req->req_size * WCratio) * para->page_MB * Read_page) / para->channel;
					else if (req->App_type == TERASORT || req->App_type == GREP) process_time = (req->req_size * para->page_MB * Read_page) / para->channel;
					else if (req->App_type == DFSIO) process_time = (ceil(req->req_size * DFSIOratio) * para->page_MB * Write_page) / para->channel;
				}

				process_time = process_time / multiple;
				process_time = process_time * multiple;

				req->response_time = ssd->current_time + process_time;
				ssd->current_time = req->response_time;
			}
			else if (req->ope == WRITE)
			{
				if (req->T_flag == FALSE) req->write_start = ssd->current_time;
				if (req->phase == MAP)
				{
					if (req->App_type == WC)
					{
						process_time = (ceil(req->req_size * WCratio) * para->page_MB * Write_page) / para->channel;
						ssd->over_provision -= ceil(req->req_size * WCratio) * para->page_MB;
					}
					else if (req->App_type == TERASORT || req->App_type == GREP)
					{
						process_time = (req->req_size * para->page_MB * Write_page) / para->channel;
						ssd->over_provision -= req->req_size * para->page_MB;
					}
					else if (req->App_type == DFSIO)
					{
						process_time = (ceil(req->req_size * DFSIOratio) * para->page_MB * Write_page) / para->channel;
						ssd->over_provision -= ceil(req->req_size * DFSIOratio) * para->page_MB;
					}
				}
				else if (req->phase == REDUCE)
				{
					if (req->App_type == WC)
					{
						process_time = (ceil(req->req_size * WCratio) * para->page_MB * Write_page) / para->channel;
						ssd->over_provision -= ceil(req->req_size * WCratio) * para->page_MB;
					}
					else if (req->App_type == TERASORT || req->App_type == GREP)
					{
						process_time = (req->req_size * para->page_MB * Write_page) / para->channel;
						ssd->over_provision -= req->req_size * para->page_MB;
					}
					else if (req->App_type == DFSIO)
					{
						process_time = (ceil(req->req_size * DFSIOratio * DFSIOratio) * para->page_MB * Write_page) / para->channel;
						ssd->over_provision -= ceil(req->req_size * DFSIOratio * DFSIOratio) * para->page_MB;
					}
				}

				process_time = process_time / multiple;
				process_time = process_time * multiple;
				process_time = garbage_collection(ssd, process_time);  //gc check 

				req->response_time = ssd->current_time + process_time;
				ssd->current_time = req->response_time;
			}
		}
		
	}
	
}

unsigned long long garbage_collection(struct ssd* ssd, unsigned long long process_time)
{
	struct parameter* para;
	para = ssd->para;
	unsigned long long GC_Normal = (5 * para->tWC) + para->tWB + para->tBERS;  //GC per block
	unsigned long long gc_time = 0;
	unsigned long multiple = pow(10, 6); // ms -> ns

	if (ssd->over_provision < ssd->gc_threshold)
	{
		//printf("gc\n");
		ssd->gc_count++;
		gc_time = GC_Normal * para->block_MB * block_size;
		gc_time = gc_time / multiple;
		gc_time = gc_time * multiple;

		process_time += gc_time;
		ssd->over_provision += block_size * para->page_MB;
	}

	return process_time;
}

void ssd_set_time(struct ssd* ssd, struct data_node* node)
{
	struct request_queue* req;
	struct task_queue* task;
	req = ssd->req_q;
	task = node->queue;

	unsigned long multiple = pow(10, 6); // ns -> ms

	while (task != NULL && req != NULL)
	{
		if (task->req_no == req->req_no)
		{
			if (req->T_flag == FALSE)
			{
				if (req->ope == READ)
				{
					task->task_stat = READ_OPE;
					task->read_start = req->read_start / multiple;
					task->read_end = req->response_time / multiple;
#ifdef DEBUG
					printf("Time: %llu Req: %d read ope get phase: %d resp: %llu\n", TIMETICK, task->req_no, task->phase, task->read_end);
#endif // DEBUG
				}
				else if (req->ope == WRITE)
				{
					task->task_stat = WRITE_OPE;
					task->write_start = req->write_start / multiple;
					task->write_end = req->response_time / multiple;
#ifdef DEBUG
					printf("Time: %llu Req: %d write ope get phase: %d resp: %llu\n", TIMETICK, task->req_no, task->phase, task->write_end);
#endif // DEBUG
				}
			}
			else if(req->T_flag == TRUE)
			{
				if (req->phase == MAP)
				{
					task->arrival_time = req->response_time / multiple;
					task->task_stat = TRANSFER_OPE;
				}
				else if(req->phase == REDUCE)
				{
					task->arrival_time = req->response_time / multiple;
					task->task_stat = TRANSFER;  
				}
				
#ifdef DEBUG
				printf("Time: %llu Req: %d transfer ope get phase: %d\n", TIMETICK, task->req_no, task->phase);
#endif // DEBUG
			}
		}
		task = task->next;
	}
}

void clear_ssd_queue(struct ssd* ssd)
{
	struct request_queue* req;
	req = ssd->req_q;
	if (req != NULL) 
	{
		if (req->ope == WRITE) ssd->write_q = remove_wq(req, ssd->write_q);
		else if (req->ope == READ) ssd->read_q = remove_wq(req, ssd->read_q);
	}
	
	ssd->req_q = NULL;
}

struct waiting_queue* remove_wq(struct request_queue* req, struct waiting_queue* queue)
{
	struct waiting_queue* temp, *prev;
	
	prev = NULL;
	if (queue->req_no == req->req_no)
	{
		temp = queue;
		queue = queue->next;
		free(temp);
	}
	else
	{
		temp = queue;
		while ((temp != NULL) && (temp->req_no != req->req_no))
		{
			prev = temp;
			temp = temp->next;
		}
		if (temp != NULL)
		{
			prev->next = temp->next;
			free(temp);
		}
	}

	return queue;
}