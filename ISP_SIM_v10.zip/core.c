#define _CRTDBG_MAP_ALLOC
#define _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES 1

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <stdbool.h>
#include <crtdbg.h>
#include <math.h>

#include "main.h"
#include "host.h"
#include "core.h"
#include "ssd.h"
#include "transfer.h"
#include "initial.h"

extern unsigned long long TIMETICK;
extern int reduce_collection[QUEUE_SIZE];
long long times = 1;
long long arrival_count = 1;

void task_execution(struct data_node* node)
{
	int i, j;
	struct cpu* cpu;
	cpu = node->cpu;

	ssd_timer(node);  //ssd timer
	for (i = 0; i < TOTAL_CORE; i++)
	{
		if (cpu->core[i]->core_stat == BUSY) core_timer(node, cpu->core[i]);  //timer->core
		else if (cpu->core[i]->core_stat == IDLE) get_core(cpu, node, i);
	}
	ssd_sim(node);  //ssd operation
}

void ssd_timer(struct data_node* node)
{
	struct task_queue* task;
	task = node->queue;

	while (task != NULL)
	{
		if (task->task_stat == READ_OPE && task->read_end == TIMETICK)
		{
			node->ssd->ssd_stat = IDLE;
			task->task_stat = WAITING;
			//printf("Time: %llu rack:%d node:%d req: %d read done ope: %d stat: %d\n", TIMETICK, task->rack_id, task->node_id, task->req_no, task->ope, task->task_stat);
		}
		else if (task->task_stat == WRITE_OPE && task->write_end == TIMETICK)
		{
			node->ssd->ssd_stat = IDLE;
			task->task_stat = COMPLETE;
			//printf("Time: %llu rack:%d node:%d req: %d write done ope: %d stat: %d phase: %d app: %d\n", TIMETICK, task->rack_id, task->node_id, task->req_no, task->ope, task->task_stat, task->phase, task->App_type);
		}
		task = task->next;
	}
	
}

void core_timer(struct data_node* node, struct core* core)
{
	struct task_queue* task;
	task = node->queue;
	unsigned long long response = 0;
	int relation = Remote;

	while (task != NULL)
	{
		if (task->req_no == core->req_no && task->task_stat == WAITING)
		{
			task->task_stat = CORE_OPE;
			core->start = TIMETICK;
			response = core_process(task);
			core->end = core->start + response;
		}
		else if (task->req_no == core->req_no && task->task_stat == CORE_OPE && core->end == TIMETICK)
		{
			//printf("Time: %llu req: %d core job finish!\n", TIMETICK, task->req_no);
			task->ope = WRITE;
			core->ope = WRITE;
			fetch_ssd_req(node, core, FALSE, core->req_no);  //fetch to ssd
			core_release(node, task);//release core
		}
		else if (task->req_no == core->req_no && task->task_stat == COMPLETE)
		{
			//printf("TIme: %llu req: %d complete!  %lld\n", TIMETICK, task->req_no, times);
			times++;
			task_update(task, Namenode->head);
			core->core_stat = IDLE;
		}
		task = task->next;
	}
}

unsigned long long core_process(struct task_queue* task)
{
	unsigned long long response_time = 0, multiple = pow(10, 3); // sec -> ms
	unsigned long long WC_MAP = (((double)task->size / (double)8.6) * multiple) + (((double)ceil(task->size * WCratio) / (double)8.6) * multiple);
	unsigned long long WC_RED = 2 * (((double)ceil(task->size * WCratio) / (double)8.6) * multiple);
	unsigned long long Tera_MAP = 2 * (((double)task->size / (double)8.6) * multiple);
	unsigned long long Tera_RED = 2 * (((double)task->size / (double)8.6) * multiple);
	unsigned long long Grep_MAP = 2 * (((double)task->size / (double)8.6) * multiple);
	unsigned long long Grep_RED = 2 * (((double)task->size / (double)8.6) * multiple);
	unsigned long long DFSIO_MAP = (((double)task->size / (double)8.6) * multiple) + (((double)ceil(task->size * DFSIOratio) / (double)8.6) * multiple);
	unsigned long long DFSIO_RED = (((double)ceil(task->size * DFSIOratio) / (double)8.6) * multiple) + (((double)ceil(task->size * DFSIOratio * DFSIOratio) / (double)8.6) * multiple);;

	if (MODE->structure == CPU_CENTRIC)
	{
		if (task->phase == MAP)
		{
			if (task->App_type == WC) response_time = MODE->map_time + WC_MAP;
			else if (task->App_type == TERASORT) response_time = MODE->map_time + Tera_MAP;
			else if (task->App_type == GREP) response_time = MODE->map_time + Grep_MAP;
			else if (task->App_type == DFSIO) response_time = MODE->map_time + DFSIO_MAP;
		}
		else if (task->phase == REDUCE)
		{
			if (task->App_type == WC) response_time = MODE->reduce_time + WC_RED;
			else if (task->App_type == TERASORT) response_time = MODE->reduce_time + Tera_RED;
			else if (task->App_type == GREP) response_time = MODE->reduce_time + Grep_RED;
			else if (task->App_type == DFSIO) response_time = MODE->reduce_time + DFSIO_RED;
		}
	}
	else if (MODE->structure == ISC_map)
	{
		if (task->phase == MAP)
		{
			if (task->App_type == WC) response_time = MODE->map_time;
			else if (task->App_type == TERASORT) response_time = MODE->map_time;
			else if (task->App_type == GREP) response_time = MODE->map_time;
			else if (task->App_type == DFSIO) response_time = MODE->map_time;
		}
		else if (task->phase == REDUCE)
		{
			if (task->App_type == WC) response_time = MODE->reduce_time + WC_RED;
			else if (task->App_type == TERASORT) response_time = MODE->reduce_time + Tera_RED;
			else if (task->App_type == GREP) response_time = MODE->reduce_time + Grep_RED;
			else if (task->App_type == DFSIO) response_time = MODE->reduce_time + DFSIO_RED;
		}
	}
	else
	{
		if (task->phase == MAP)
		{
			if (task->App_type == WC) response_time = MODE->map_time;
			else if (task->App_type == TERASORT) response_time = MODE->map_time;
			else if (task->App_type == GREP) response_time = MODE->map_time;
			else if (task->App_type == DFSIO) response_time = MODE->map_time;
		}
		else if (task->phase == REDUCE)
		{
			if (task->App_type == WC) response_time = MODE->reduce_time;
			else if (task->App_type == TERASORT) response_time = MODE->reduce_time;
			else if (task->App_type == GREP) response_time = MODE->reduce_time;
			else if (task->App_type == DFSIO) response_time = MODE->reduce_time;
		}
	}

	return response_time;
}

void core_release(struct data_node* node, struct task_queue* task)
{
	int i, clear = FALSE;

	for (i = 0; i < node->cpu->total_task; i++)
	{
		if (node->cpu->Execution_queue[i] == task->req_no)
		{
			if (MODE->scheduler == FIFO)
			{
				node->cpu->location--;
				node->cpu->Execution_queue[i] = 0;
				node->cpu->Dep_exe[i] = 0;
				node->cpu->Prio_exe[i] = 0;
				
			}
			else if (MODE->scheduler == WAS)
			{
				node->cpu->Execution_queue[i] = 0;
				node->cpu->Dep_exe[i] = 0;
				node->cpu->Prio_exe[i] = 0;
			}
			clear = TRUE;
		}
	}
	
	if (clear == TRUE)
	{
		node->cpu->total_task--;
		if (node->cpu->total_task > 0)
		{
			for (i = 0; i < node->cpu->total_task; i++)
			{
				if (node->cpu->Execution_queue[i] == 0)
				{
					node->cpu->Execution_queue[i] = node->cpu->Execution_queue[i + 1];
					node->cpu->Execution_queue[i + 1] = 0;
					node->cpu->Prio_exe[i] = node->cpu->Prio_exe[i + 1];
					node->cpu->Prio_exe[i + 1] = 0;
					node->cpu->Dep_exe[i] = node->cpu->Dep_exe[i + 1];
					node->cpu->Dep_exe[i + 1] = 0;
				}
			}
		}
	}
}

void task_update(struct task_queue* task, struct Input* input)
{
	struct Input* temp;
	temp = input;
	struct sub_task* sub;
	while (temp != NULL)
	{
		if (temp->App_no == task->App_no)
		{
			sub = temp->sub;
			while (sub != NULL)
			{
				if (sub->req_no == task->req_no)
				{
					sub->read_start = task->read_start;
					sub->read_end = task->read_end;
					sub->write_start = task->write_start;
					sub->write_end = task->write_end;
					sub->task_start_time = task->read_start;
					sub->task_end_time = task->write_end;
					sub->flag = FALSE;
				}
				sub = sub->next;
			}
		}
		temp = temp->next;
	}
}

void get_core(struct cpu* cpu, struct data_node* node, int id)
{
	struct task_queue* task;
	task = node->queue;
	struct core* core;
	core = cpu->core[id];
	int i, flag = FALSE;

	for (i = 0; i < cpu->total_task; i++)
	{
		if (cpu->Execution_queue[i] != 0 && flag == FALSE)
		{
			task = node->queue;
			while (task != NULL)
			{
				if (task->req_no == cpu->Execution_queue[i] && task->task_stat == SCHEDULED)
				{
					core->ope = task->ope;
					core->phase = task->phase;
					core->req_no = task->req_no;
					core->size = task->size;
					core->App_no = task->App_no;
					core->App_type = task->App_type;
					
					core->core_stat = BUSY;
					task->task_stat = PROCESS;

					flag = TRUE;
				}
				task = task->next;
			}
		}
	}
	
	if (flag == TRUE) fetch_ssd_req(node, core, FALSE, core->req_no);  //fetch ssd req
}

void fetch_ssd_req(struct data_node* node, struct core* core, int T_flag, int req)
{
	struct ssd* ssd;
	ssd = node->ssd;
	
	if (T_flag == FALSE)
	{
		if (core->ope == READ)
		{
			ssd->read_current = (struct waiting_queue*)malloc(sizeof(struct waiting_queue));

			ssd->read_current->App_no = core->App_no;
			ssd->read_current->App_type = core->App_type;
			ssd->read_current->req_no = core->req_no;
			ssd->read_current->ope = core->ope;
			ssd->read_current->req_size = core->size;
			ssd->read_current->T_flag = T_flag;
			ssd->read_current->phase = core->phase;
			ssd->read_current->flag = FALSE;
			ssd->read_current->next = NULL;

			if (ssd->read_q == NULL) ssd->read_q = ssd->read_current;
			else ssd->read_prev->next = ssd->read_current;
			ssd->read_prev = ssd->read_current;
		}
		else if (core->ope == WRITE)
		{
			ssd->write_current = (struct waiting_queue*)malloc(sizeof(struct waiting_queue));

			ssd->write_current->App_no = core->App_no;
			ssd->write_current->App_type = core->App_type;
			ssd->write_current->req_no = core->req_no;
			ssd->write_current->ope = core->ope;
			ssd->write_current->req_size = core->size;
			ssd->write_current->T_flag = T_flag;
			ssd->write_current->phase = core->phase;
			ssd->write_current->flag = FALSE;
			ssd->write_current->next = NULL;

			if (ssd->write_q == NULL) ssd->write_q = ssd->write_current;
			else ssd->write_prev->next = ssd->write_current;
			ssd->write_prev = ssd->write_current;
		}
	}
	else
	{
		struct task_queue* task;
		task = node->queue;
		while (task != NULL)
		{
			if (task->req_no == req)
			{
				ssd->write_current = (struct waiting_queue*)malloc(sizeof(struct waiting_queue));

				ssd->write_current->App_no = task->App_no;
				ssd->write_current->App_type = task->App_type;
				ssd->write_current->req_no = task->req_no;
				ssd->write_current->ope = WRITE;
				ssd->write_current->req_size = task->size;
				ssd->write_current->T_flag = T_flag;
				ssd->write_current->phase = task->phase;
				ssd->write_current->flag = FALSE;
				ssd->write_current->next = NULL;

				if (ssd->write_q == NULL) ssd->write_q = ssd->write_current;
				else ssd->write_prev->next = ssd->write_current;
				ssd->write_prev = ssd->write_current;
			}
			task = task->next;
		}
	}
	
}

void task_presetting(struct data_node* node)
{
	int task_flag = FALSE;
	task_flag = task_check(node);
	if (task_flag == TRUE)
	{
		task_schedule(node);
		/*struct cpu* cpu;
		cpu = node->cpu;
		int i;

		printf("rack node: %d : ", node->node_id);
		for (i = 0; i < cpu->total_task; i++)
		{
			printf("%d ", cpu->Execution_queue[i]);
		}
		printf("\n");*/
	}
}

int task_check(struct data_node* node)
{
	int value = FALSE;
	int reduce_check = FALSE;
	struct task_queue* temp;
	temp = node->queue;

	while (temp != NULL)
	{
		if (temp->phase == MAP)
		{
			if (temp->task_stat == IDLE && temp->arrival_time != NOSET)
			{
				
				//printf("time: %llu arrival_count: %lld\n", TIMETICK, arrival_count);
				//arrival_count++;
				
				node->cpu->Ready_queue[node->cpu->count] = temp->req_no;
				node->cpu->Prio_keep[node->cpu->count] = temp->priority;
				node->cpu->Dep_keep[node->cpu->count] = temp->rt_total;
				node->cpu->count++;
				value = TRUE;
				temp->task_stat = ONGOING;
			}
		}
		else if (temp->phase == REDUCE)
		{
			reduce_check = reduce_task_check(temp);  //check reduce related task's status
			
			if (temp->task_stat == IDLE  && reduce_check == TRUE)
			{
				//printf("req: %d\n", temp->req_no);
				node->cpu->Ready_queue[node->cpu->count] = temp->req_no;
				node->cpu->Prio_keep[node->cpu->count] = temp->priority;
				node->cpu->Dep_keep[node->cpu->count] = temp->rt_total;
				node->cpu->count++;
				value = TRUE;
				temp->task_stat = ONGOING;
			}
		}
		temp = temp->next;
	}

	return value;
}

int reduce_task_check(struct task_queue* task)
{
	int check = FALSE;
	if (reduce_collection[task->req_no] == task->rt_total)
	{
		check = TRUE;
	}
	
	return check;
}

void task_schedule(struct data_node* node)
{
	int i, j;
	struct task_queue* task;
	struct cpu* cpu;
	cpu = node->cpu;
	int sort = 0;

	if (MODE->scheduler == FIFO)
	{
		for (i = cpu->location; i < cpu->location + cpu->count; i++)
		{
			cpu->Execution_queue[i] = cpu->Ready_queue[sort];
			sort++;
			cpu->total_task++;
			task = node->queue;
			while (task != NULL)
			{
				if (task->req_no == cpu->Execution_queue[i] && task->task_stat == ONGOING) task->task_stat = SCHEDULED;
				task = task->next;
			}
		}
		
		cpu->location += cpu->count;
		cpu->count = 0;
	}
	else if (MODE->scheduler == WAS)
	{
		for (i = 0; i < cpu->count; i++)
		{
			workload_aware_scheduler(cpu, i);//WAS
			task = node->queue;
			while (task != NULL)
			{
				if (task->req_no == cpu->Ready_queue[i] && task->task_stat == ONGOING) task->task_stat = SCHEDULED;
				task = task->next;
			}

		}
		cpu->count = 0;
	}
	for (i = 0; i < QUEUE_SIZE; i++)  //reset ready queue
	{
		cpu->Ready_queue[i] = 0;
		cpu->Prio_keep[i] = 0;
		cpu->Dep_keep[i] = 0;
	}
}

void workload_aware_scheduler(struct cpu* cpu, int num)
{
	int i, req, req_compare, prio, prio_compare, dep, dep_compare;

	req = cpu->Ready_queue[num];
	prio = cpu->Prio_keep[num];
	dep = cpu->Dep_keep[num];
	for (i = 0; i < cpu->total_task + 1; i++)
	{
		if (cpu->Execution_queue[i] != 0)
		{
			if (prio < cpu->Prio_exe[i])
			{
				req_compare = cpu->Execution_queue[i];
				prio_compare = cpu->Prio_exe[i];
				dep_compare = cpu->Dep_exe[i];

				cpu->Execution_queue[i] = req;
				cpu->Prio_exe[i] = prio;
				cpu->Dep_exe[i] = dep;

				req = req_compare;
				prio = prio_compare;
				dep = dep_compare;
			}
			else if (prio == cpu->Prio_exe[i])
			{
				if (dep > cpu->Dep_exe[i])
				{
					req_compare = cpu->Execution_queue[i];
					prio_compare = cpu->Prio_exe[i];
					dep_compare = cpu->Dep_exe[i];

					cpu->Execution_queue[i] = req;
					cpu->Prio_exe[i] = prio;
					cpu->Dep_exe[i] = dep;

					req = req_compare;
					prio = prio_compare;
					dep = dep_compare;
				}
			}
		}
		else
		{
			cpu->Execution_queue[i] = req;
			cpu->Prio_exe[i] = prio;
			cpu->Dep_exe[i] = dep;
		}
	}
	cpu->total_task++;

	return cpu;
}