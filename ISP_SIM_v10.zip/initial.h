#pragma once

#define TOTAL_RACK 2
#define TOTAL_NODE 3
#define TOTAL_CORE 2
#define QUEUE_SIZE 10000

#define replica 3
#define locality 5000
#define block_size 64 //MB

#define NOSET 1000000000
#define TRUE 1
#define FALSE 0

#define IDLE 0
#define ONGOING 1  //task presetting
#define SCHEDULED 2  //scheduler
#define PROCESS 3  //get core
#define READ_OPE 4
#define WAITING 5  //waiting for core after read ope
#define CORE_OPE 6  //core execution
#define WRITE_OPE 7
#define TRANSFER 98  //task under transfer
#define TRANSFER_OPE 99  //task under transfer write ope
#define COMPLETE 100

#define CPU_CENTRIC 0
#define ISC_map 1
#define ISC_both 2
#define WTE 3

#define FIFO 0
#define WAS 1

struct mode
{
	int structure; //CPU-0 or ISC-1 or ISP-2 or WTE-3
	int scheduler; //FIFO or WAS

	int locality_create_mode;  //0 = FALSE, 1 = TRUE
	int dependency_create_mode;  //0 = FALSE, 1 = TRUE

	double gc_threshold;
	double ssd_budget_ratio;

	int memory_exist;

	unsigned long long map_time;
	unsigned long long reduce_time;
}*MODE;

struct data_locality
{
	int rack[locality][replica];
	int node[locality][replica];
}*DATA;

void initialize();
void load_mode();
void load_input(struct name_node* namenode);
void load_locality();
int locality_gen_rack(int previous);
int locality_gen_node(int previous);
void split_task(struct name_node* namenode);
void create_sub(struct Input* input, long long size, int phase);
void load_dependency(struct name_node* namenode);
void initial_ac(struct name_node* namenode);
struct sub_task* rt_dep_update(struct sub_task* sub);
struct rack* initial_rack(struct rack* rack, int id);
struct data_node* initial_node(struct data_node* node, int id);
struct cpu* initial_cpu(struct cpu* cpu);
struct core* initial_core(struct core* core, int id);
struct ssd* initial_ssd(struct ssd* ssd);
struct parameter* initial_parameter(struct parameter* para);
struct rack_info* initial_rack_info(struct rack_info* info, int id, struct name_node* namenode);
struct node_info* initial_node_info(struct node_info* info, int id, int rack_id, struct name_node* namenode);
struct transfer_cluster* initial_transfer_cluster(struct transfer_cluster* cluster);
struct Rack_to_Rack* initial_Rack_to_Rack(struct Rack_to_Rack* R_R);
struct Node_to_Node* initial_Node_to_Node(struct Node_to_Node* N_N, int id);