#define _CRTDBG_MAP_ALLOC
#define _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES 1

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <stdbool.h>
#include <crtdbg.h>
#include <math.h>

#include "main.h"
#include "host.h"
#include "core.h"
#include "ssd.h"
#include "transfer.h"
#include "initial.h"

extern unsigned long long TIMETICK;
extern int reduce_collection[QUEUE_SIZE];
long long transfer_count = 1;
long long localtransfer_count = 1;

void data_to_node(struct data_node* node, int rack_id, int node_id, struct sub_task* sub)
{
	int locality_check = Remote;

	node->current = (struct task_queue*)malloc(sizeof(struct task_queue));

	node->current->App_no = sub->App_no;
	node->current->App_type = sub->App_type;
	node->current->req_no = sub->req_no;
	node->current->dep_task_no = sub->dep_task_no;
	node->current->rt_total = sub->rt_total;
	node->current->rack_id = rack_id;
	node->current->node_id = node_id;
	node->current->priority = sub->priority;
	node->current->phase = sub->phase;
	node->current->size = sub->size;

	node->current->ope = READ;
	node->current->task_stat = IDLE;
	if (node->current->phase == MAP)
	{
		locality_check = locality_get(sub, sub->rack_id, sub->node_id);  //locality check
		if (locality_check == Local) node->current->arrival_time = TIMETICK;
		else
		{
			node->current->arrival_time = NOSET;
			/*printf("count: %lld\n", transfer_count);
			transfer_count++;*/
		}
	}
	else if (node->current->phase == REDUCE)
	{
		node->current->arrival_time = NOSET;
	}
	

	node->current->task_start_time = sub->task_start_time;
	node->current->task_end_time = sub->task_end_time;
	node->current->read_start = sub->read_start;
	node->current->read_end = sub->read_end;
	node->current->write_start = sub->write_start;
	node->current->write_end = sub->write_end;

	node->current->next = NULL;

	if (node->queue == NULL) node->queue = node->current;
	else node->prev->next = node->current;
	node->prev = node->current;

}

void data_assignment(struct Input* input)
{
	struct sub_task* sub;
	struct Input* temp;
	temp = input;
	int i, j;

	while (temp != NULL)
	{
		for (i = 0; i < TOTAL_RACK; i++)
		{
			for (j = 0; j < TOTAL_NODE; j++)
			{
				sub = temp->sub;
				while (sub != NULL)
				{
					if (sub->rack_id == i && sub->node_id == j)
					{
						data_to_node(Namenode->rack[i]->data_node[j], i, j, sub);
					}
					sub = sub->next;
				}
			}
		}
		temp = temp->next;
	}
}

void get_transfer(struct transfer_cluster* cluster, int relation, int rack_id, int req_no, int Prio, int rt_total, int dep_task, int phase)
{
	if (relation == Remote) Add_remote(cluster->R_R, req_no, Prio, rt_total, dep_task);
	else if (relation == Rack_local) Add_local(cluster->N_N[rack_id], req_no, Prio, rt_total, dep_task);
	else if (relation == Local)
	{
		if (phase == REDUCE)
		{
			reduce_collection[dep_task]++;
			//printf("Time: %llu req : %d dep_task: %d collection %d\n", TIMETICK, req_no, dep_task, reduce_collection[dep_task]);
		}
	}
}

void Add_local(struct Node_to_Node* N_N, int req_no, int Prio, int rt_total, int dep_task)
{
	int i, req, req_compare, prio, prio_compare, rt, rt_compare, dep, dep_compare;
	//printf("time: %llu req: %d transfer scheduler\n", TIMETICK, req_no);
	if (MODE->scheduler == FIFO)
	{
		N_N->queue[N_N->count] = req_no;
		N_N->record_prio[N_N->count] = Prio;
		N_N->record_rt[N_N->count] = rt_total;
		N_N->record_dep_task[N_N->count] = dep_task;
		N_N->count++;
		N_N->total_req++;
	}
	else if (MODE->scheduler == WAS)
	{
		req = req_no;
		prio = Prio;
		rt = rt_total;
		dep = dep_task;
		for (i = 0; i < N_N->total_req + 1; i++)
		{
			if (N_N->queue[i] != 0)
			{
				if (prio < N_N->record_prio[i])
				{
					req_compare = N_N->queue[i];
					prio_compare = N_N->record_prio[i];
					rt_compare = N_N->record_rt[i];
					dep_compare = N_N->record_dep_task[i];

					N_N->queue[i] = req;
					N_N->record_prio[i] = prio;
					N_N->record_rt[i] = rt;
					N_N->record_dep_task[i] = dep;

					req = req_compare;
					prio = prio_compare;
					rt = rt_compare;
					dep = dep_compare;
				}
				else if (prio == N_N->record_prio[i])
				{
					if (rt > N_N->record_rt[i])
					{
						req_compare = N_N->queue[i];
						prio_compare = N_N->record_prio[i];
						rt_compare = N_N->record_rt[i];
						dep_compare = N_N->record_dep_task[i];

						N_N->queue[i] = req;
						N_N->record_prio[i] = prio;
						N_N->record_rt[i] = rt;
						N_N->record_dep_task[i] = dep;

						req = req_compare;
						prio = prio_compare;
						rt = rt_compare;
						dep = dep_compare;
					}
				}
			}
			else
			{
				N_N->queue[i] = req;
				N_N->record_prio[i] = prio;
				N_N->record_rt[i] = rt;
				N_N->record_dep_task[i] = dep;
			}
		}
		N_N->count++;
		N_N->total_req++;
	}

}

void Add_remote(struct Rack_to_Rack* R_R, int req_no, int Prio, int rt_total, int dep_task)
{
	int i, req, req_compare, prio, prio_compare, rt, rt_compare, dep, dep_compare;
	//printf("time: %llu req: %d transfer scheduler\n", TIMETICK, req_no);
	if (MODE->scheduler == FIFO)
	{
		R_R->queue[R_R->count] = req_no;
		R_R->record_prio[R_R->count] = Prio;
		R_R->record_rt[R_R->count] = rt_total;
		R_R->record_dep_task[R_R->count] = dep_task;
		R_R->count++;
		R_R->total_req++;
	}
	else if (MODE->scheduler == WAS)
	{
		req = req_no;
		prio = Prio;
		rt = rt_total;
		dep = dep_task;
		for (i = 0; i < R_R->total_req + 1; i++)
		{
			if (R_R->queue[i] != 0)
			{
				if (prio < R_R->record_prio[i])
				{
					req_compare = R_R->queue[i];
					prio_compare = R_R->record_prio[i];
					rt_compare = R_R->record_rt[i];
					dep_compare = R_R->record_dep_task[i];

					R_R->queue[i] = req;
					R_R->record_prio[i] = prio;
					R_R->record_rt[i] = rt;
					R_R->record_dep_task[i] = dep;

					req = req_compare;
					prio = prio_compare;
					rt = rt_compare;
					dep = dep_compare;
				}
				else if (prio == R_R->record_prio[i])
				{
					if (rt > R_R->record_rt[i])
					{
						req_compare = R_R->queue[i];
						prio_compare = R_R->record_prio[i];
						rt_compare = R_R->record_rt[i];
						dep_compare = R_R->record_dep_task[i];

						R_R->queue[i] = req;
						R_R->record_prio[i] = prio;
						R_R->record_rt[i] = rt;
						R_R->record_dep_task[i] = dep;

						req = req_compare;
						prio = prio_compare;
						rt = rt_compare;
						dep = dep_compare;
					}
				}
			}
			else
			{
				R_R->queue[i] = req;
				R_R->record_prio[i] = prio;
				R_R->record_rt[i] = rt;
				R_R->record_dep_task[i] = dep;
			}
		}
		R_R->count++;
		R_R->total_req++;
	}

}

struct name_node* transfer_timer(struct name_node* namenode)
{
	int i;
	
	namenode = transfer_ssd_preset(namenode);  //set ssd IDLE

	CLUSTER->R_R = remote_timer(CLUSTER->R_R, namenode);  //remote timer
	
	for (i = 0; i < TOTAL_RACK; i++)
	{
		CLUSTER->N_N[i] = local_timer(CLUSTER->N_N[i], namenode);  //local timer
	}

	return namenode;
}

struct name_node* transfer_ssd_preset(struct name_node* namenode)
{
	struct task_queue* task;
	struct ssd* ssd;
	int rack, node;

	for (rack = 0; rack < TOTAL_RACK; rack++)
	{
		for (node = 0; node < TOTAL_NODE; node++)
		{
			task = namenode->rack[rack]->data_node[node]->queue;
			ssd = namenode->rack[rack]->data_node[node]->ssd;
			while (task != NULL)
			{
				if (ssd->ssd_stat == BUSY)
				{
					if (task->task_stat == TRANSFER_OPE && task->arrival_time == TIMETICK)
					{
						task->task_stat = IDLE;
						ssd->ssd_stat = IDLE;
					}
					else if (task->task_stat == TRANSFER && task->arrival_time == TIMETICK)  //for reduce task
					{
						task->task_stat = IDLE;
						ssd->ssd_stat = IDLE;
						reduce_collection[task->req_no]++;
					}
				}
				task = task->next;
			}
		}
	}

	return namenode;
}

struct Rack_to_Rack* remote_timer(struct Rack_to_Rack* R_R, struct name_node* namenode)
{
	struct Rack_to_Rack* temp;
	temp = R_R;
	struct data_transfer_list* list;
	list = temp->list;
	struct Input* input;
	input = namenode->head;
	struct sub_task* sub;
	struct task_queue* task;
	int i, rack_target = 0, node_target= 0;

	if (temp->stat == BUSY)
	{
		if (temp->current_time == TIMETICK && temp->total_req > 0)
		{
			temp->stat = IDLE;
			while (list != NULL)
			{
				if (list->req_no == temp->current_req && list->phase == MAP)
				{
					list->transfer_flag = done;

					if(MODE->memory_exist == FALSE) fetch_ssd_req(Namenode->rack[list->rack_id]->data_node[list->node_id], Namenode->rack[list->rack_id]->data_node[list->node_id]->cpu->core, TRUE, list->req_no);
					else if (MODE->memory_exist == TRUE)
					{
						task = namenode->rack[list->rack_id]->data_node[list->node_id]->queue;
						while (task != NULL)
						{
							if (task->req_no == list->req_no) task->arrival_time = temp->current_time;
							task = task->next;
						}
					}
				}
				else if (list->req_no == temp->current_req && list->phase == REDUCE)
				{
					list->transfer_flag = done;
					
					while (input != NULL)
					{
						if (input->App_no == list->App_no)
						{
							//printf("hi\n");
							sub = input->sub;
							while (sub != NULL)
							{
								if (sub->req_no == list->dep_task_no)
								{
									//printf("hello %d %d\n", sub->rack_id, sub->node_id);
									rack_target = sub->rack_id;
									node_target = sub->node_id;
								}
								sub = sub->next;
							}
						}
						input = input->next;
					}
					//update collection and task arrival time
					reduce_collection[list->dep_task_no]++;
					//printf("req: %d rack target: %d node target: %d\n", list->dep_task_no, rack_target, node_target);
					task = namenode->rack[rack_target]->data_node[node_target]->queue;
					while (task != NULL)
					{
						if (task->req_no == list->dep_task_no) task->arrival_time = temp->current_time;
						task = task->next;
					}
					/*fetch_ssd_req(namenode->rack[rack_target]->data_node[node_target], namenode->rack[rack_target]->data_node[node_target]->cpu->core, TRUE, list->dep_task_no);*/
				}
				list = list->next;
			}

			for (i = 0; i < temp->total_req; i++)
			{
				if (temp->queue[i] == temp->current_req)
				{
					temp->queue[i] = 0;
					temp->record_dep_task[i] = 0;
					temp->record_prio[i] = 0;
					temp->record_rt[i] = 0;
				}
			}
			temp->total_req--;
			temp->count--;
			temp->current_req = 0;

			for (i = 0; i < temp->total_req; i++)
			{
				if (temp->queue[i] == 0)
				{
					temp->queue[i] = temp->queue[i + 1];
					temp->record_rt[i] = temp->record_rt[i + 1];
					temp->record_prio[i] = temp->record_prio[i + 1];
					temp->record_dep_task[i] = temp->record_dep_task[i + 1];
					temp->queue[i + 1] = 0;
					temp->record_rt[i + 1] = 0;
					temp->record_prio[i + 1] = 0;
					temp->record_dep_task[i + 1] = 0;
				}
			}
		}
	}
	return R_R;
}

struct Node_to_Node* local_timer(struct Node_to_Node* N_N, struct name_node* namenode)
{
	struct Node_to_Node* temp;
	temp = N_N;
	struct data_transfer_list* list;
	list = temp->list;
	struct Input* input;
	input = namenode->head;
	struct sub_task* sub;
	struct task_queue* task;
	int i, rack_target = 0, node_target = 0;

	if (temp->stat == BUSY)
	{
		if (temp->current_time == TIMETICK && temp->total_req > 0)
		{
			temp->stat = IDLE;
			while (list != NULL)
			{
				if (list->req_no == temp->current_req && list->phase == MAP && list->transfer_flag == pending)
				{
					list->transfer_flag = done;

					if (MODE->memory_exist == FALSE) fetch_ssd_req(Namenode->rack[list->rack_id]->data_node[list->node_id], Namenode->rack[list->rack_id]->data_node[list->node_id]->cpu->core, TRUE, list->req_no);
					else if (MODE->memory_exist == TRUE)
					{
						task = namenode->rack[list->rack_id]->data_node[list->node_id]->queue;
						while (task != NULL)
						{
							if (task->req_no == list->req_no) task->arrival_time = temp->current_time;
							task = task->next;
						}
					}
					
				}
				else if (list->req_no == temp->current_req && list->phase == REDUCE && list->transfer_flag == pending)
				{
					list->transfer_flag = done;
					
					while (input != NULL)
					{
						if (input->App_no == list->App_no)
						{
							sub = input->sub;
							while (sub != NULL)
							{
								if (sub->req_no == list->dep_task_no)
								{
									rack_target = sub->rack_id;
									node_target = sub->node_id;
								}
								sub = sub->next;
							}
						}
						input = input->next;
					}
					//update collection and task arrival time
					reduce_collection[list->dep_task_no]++;
					task = namenode->rack[rack_target]->data_node[node_target]->queue;
					while (task != NULL)
					{
						if (task->req_no == list->dep_task_no) task->arrival_time = temp->current_time;
						task = task->next;
					}
					/*fetch_ssd_req(namenode->rack[rack_target]->data_node[node_target], namenode->rack[rack_target]->data_node[node_target]->cpu->core, TRUE, list->dep_task_no);*/
				}
				list = list->next;
			}

			for (i = 0; i < temp->total_req; i++)
			{
				if (temp->queue[i] == temp->current_req)
				{
					temp->queue[i] = 0;
					temp->record_dep_task[i] = 0;
					temp->record_prio[i] = 0;
					temp->record_rt[i] = 0;
				}
			}
			temp->total_req--;
			temp->count--;
			temp->current_req = 0;

			for (i = 0; i < temp->total_req; i++)
			{
				if (temp->queue[i] == 0)
				{
					temp->queue[i] = temp->queue[i + 1];
					temp->record_rt[i] = temp->record_rt[i + 1];
					temp->record_prio[i] = temp->record_prio[i + 1];
					temp->record_dep_task[i] = temp->record_dep_task[i + 1];
					temp->queue[i + 1] = 0;
					temp->record_rt[i + 1] = 0;
					temp->record_prio[i + 1] = 0;
					temp->record_dep_task[i + 1] = 0;
				}
			}
		}
	}

	return N_N;
}

void transfer_process(struct transfer_cluster* cluster)
{
	int i;

	transfer_sim_remote(cluster->R_R, Namenode->head);  //Remote sim
	for (i = 0; i < TOTAL_RACK; i++)  //Rack_local sim
	{
		transfer_sim_local(cluster->N_N[i], Namenode->head);
	}
}

void transfer_sim_remote(struct Rack_to_Rack* R_R, struct Input* input)
{
	int i, flag = TRUE;
	struct Input* temp;
	struct sub_task* sub;

	if (R_R->stat == IDLE)
	{
		if (R_R->total_req > 0)
		{
			for (i = 0; i < R_R->total_req; i++)
			{
				temp = input;
				while (temp != NULL)
				{
					sub = temp->sub;
					while (sub != NULL)
					{
						if (sub->req_no == R_R->queue[i] && flag == TRUE)
						{
							R_R->t_queue = get_info_remote(R_R->t_queue, sub, R_R);  //estimate
							remote_listing(R_R, R_R->t_queue);  //list fetch
							R_R->stat = BUSY;
							flag = FALSE;
							R_R->t_queue = NULL;
						}
						sub = sub->next;
					}
					temp = temp->next;
				}
			}
		}
	}
	
}

struct transfer_estimation_queue* get_info_remote(struct transfer_estimation_queue* queue, struct sub_task* sub, struct Rack_to_Rack* R_R)
{
	unsigned long multiple = pow(10, 3); // s -> ms

	queue = (struct transfer_estimation_queue*)malloc(sizeof(struct transfer_estimation_queue));

	if (R_R->current_time < TIMETICK) R_R->current_time = TIMETICK;

	queue->App_no = sub->App_no;
	queue->App_type = sub->App_type;
	queue->req_no = sub->req_no;
	queue->dep_task_no = sub->dep_task_no;
	queue->size = sub->size;

	if (sub->flag == TRUE)
	{
		queue->phase = MAP;
		queue->rack_id = sub->rack_id;
		queue->node_id = sub->node_id;
		queue->transfer_time = ((double)queue->size / (double)TRANS->R_to_R) * multiple;

		//printf("time: %llu remote transfer get info %lld\n", TIMETICK, transfer_count);
		//transfer_count++;
	}
	else
	{
		queue->phase = REDUCE;
		queue->rack_id = sub->rack_id;
		queue->node_id = sub->node_id;
		if (queue->App_type == WC) queue->transfer_time = ((double)ceil(queue->size * WCratio) / (double)TRANS->R_to_R) * multiple;
		else if (queue->App_type == TERASORT || queue->App_type == GREP) queue->transfer_time = ((double)queue->size / (double)TRANS->R_to_R) * multiple;
		else if(queue->App_type == DFSIO) queue->transfer_time = ((double)ceil(queue->size * DFSIOratio) / (double)TRANS->R_to_R)* multiple;
	}
	
	queue->data_in = TIMETICK;
	
	queue->transfer_time = queue->transfer_time / 1;
	queue->delay_time = R_R->current_time - queue->data_in;
	queue->data_out = queue->data_in + queue->delay_time + queue->transfer_time;

	R_R->current_time = queue->data_out;
	R_R->current_req = queue->req_no;

	return queue;
}

void remote_listing(struct Rack_to_Rack* R_R, struct transfer_estimation_queue* queue)
{
	R_R->current = (struct data_transfer_list*)malloc(sizeof(struct data_transfer_list));

	R_R->current->App_no = queue->App_no;
	R_R->current->App_type = queue->App_type;
	R_R->current->req_no = queue->req_no;
	R_R->current->size = queue->size;
	R_R->current->dep_task_no = queue->dep_task_no;

	R_R->current->rack_id = queue->rack_id;
	R_R->current->node_id = queue->node_id;
	R_R->current->phase = queue->phase;

	R_R->current->data_in = queue->data_in;
	R_R->current->data_out = queue->data_out;
	R_R->current->transfer_time = queue->transfer_time;
	R_R->current->transfer_flag = pending;

	R_R->current->next = NULL;

	if (R_R->list == NULL) R_R->list = R_R->current;
	else R_R->prev->next = R_R->current;
	R_R->prev = R_R->current;
}

void transfer_sim_local(struct Node_to_Node* N_N, struct Input* input)
{
	int i, flag = TRUE;
	struct Input* temp;
	struct sub_task* sub;
	
	if (N_N->stat == IDLE)
	{
		if (N_N->total_req > 0)
		{
			for (i = 0; i < N_N->total_req; i++)
			{
				temp = input;
				while (temp != NULL)
				{
					sub = temp->sub;
					while (sub != NULL)
					{
						if (sub->req_no == N_N->queue[i] && flag == TRUE)
						{
							N_N->t_queue = get_info_local(N_N->t_queue, sub, N_N);  //estimate
							local_listing(N_N, N_N->t_queue);  //list fetch
							N_N->stat = BUSY;
							flag = FALSE;
							N_N->t_queue = NULL;
						}
						sub = sub->next;
					}
					temp = temp->next;
				}
			}
		}
	}

}

struct transfer_estimation_queue* get_info_local(struct transfer_estimation_queue* queue, struct sub_task* sub, struct Node_to_Node* N_N)
{
	unsigned long multiple = pow(10, 3); // s -> ms

	queue = (struct transfer_estimation_queue*)malloc(sizeof(struct transfer_estimation_queue));

	if (N_N->current_time < TIMETICK) N_N->current_time = TIMETICK;

	queue->App_no = sub->App_no;
	queue->App_type = sub->App_type;
	queue->req_no = sub->req_no;
	queue->dep_task_no = sub->dep_task_no;
	queue->size = sub->size;

	if (sub->flag == TRUE)
	{
		queue->phase = MAP;
		queue->rack_id = sub->rack_id;
		queue->node_id = sub->node_id;
		queue->transfer_time = ((double)queue->size / (double)TRANS->R_to_R) * multiple;

		//printf("time: %llu local transfer get info %lld\n", TIMETICK, localtransfer_count);
		//localtransfer_count++;
	}
	else
	{
		queue->phase = REDUCE;
		queue->rack_id = sub->rack_id;
		queue->node_id = sub->node_id;
		if (queue->App_type == WC) queue->transfer_time = ((double)ceil(queue->size * WCratio) / (double)TRANS->R_to_R) * multiple;
		else if (queue->App_type == TERASORT || queue->App_type == GREP) queue->transfer_time = ((double)queue->size / (double)TRANS->R_to_R) * multiple;
		else if (queue->App_type == DFSIO) queue->transfer_time = ((double)ceil(queue->size * DFSIOratio) / (double)TRANS->R_to_R) * multiple;
	}

	queue->data_in = TIMETICK;
	
	queue->transfer_time = queue->transfer_time / 1;
	queue->delay_time = N_N->current_time - queue->data_in;
	queue->data_out = queue->data_in + queue->delay_time + queue->transfer_time;

	N_N->current_time = queue->data_out;
	N_N->current_req = queue->req_no;

	return queue;
}

void local_listing(struct Node_to_Node* N_N, struct transfer_estimation_queue* queue)
{
	N_N->current = (struct data_transfer_list*)malloc(sizeof(struct data_transfer_list));

	N_N->current->App_no = queue->App_no;
	N_N->current->App_type = queue->App_type;
	N_N->current->req_no = queue->req_no;
	N_N->current->size = queue->size;
	N_N->current->dep_task_no = queue->dep_task_no;

	N_N->current->rack_id = queue->rack_id;
	N_N->current->node_id = queue->node_id;
	N_N->current->phase = queue->phase;

	N_N->current->data_in = queue->data_in;
	N_N->current->data_out = queue->data_out;
	N_N->current->transfer_time = queue->transfer_time;
	N_N->current->transfer_flag = pending;
	
	N_N->current->next = NULL;

	if (N_N->list == NULL) N_N->list = N_N->current;
	else N_N->prev->next = N_N->current;
	N_N->prev = N_N->current;
}

