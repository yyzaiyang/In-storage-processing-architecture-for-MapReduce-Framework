#pragma once

#define READ 1
#define WRITE 0

struct ssd
{
	int ssd_stat;
	unsigned long long current_time;

	int gc_count;
	unsigned long long total_page;
	unsigned long long over_provision;
	unsigned long long gc_threshold;

	struct parameter* para;
	struct request_queue* req_q;
	
	struct waiting_queue* read_current;
	struct waiting_queue* read_prev;
	struct waiting_queue* read_q;

	struct waiting_queue* write_current;
	struct waiting_queue* write_prev;
	struct waiting_queue* write_q;
};

struct parameter
{
	unsigned long long tPROG;     //program time
	unsigned long long tBERS;     //block erase time
	unsigned long long tWC;       //write cycle time
	unsigned long long tR;        //data transfer from cell to register
	unsigned long long tRC;       //read cycle time
	unsigned long long tWB;       //WE high to busy

	unsigned long long channel;
	unsigned long long chip;
	unsigned long long die;
	unsigned long long plane;
	unsigned long long block;
	unsigned long long page;
	unsigned long long sub_page;

	long long subpage_capacity;  //bytes
	long long page_capacity;
	long long sector_capacity;

	long long page_MB;
	long long block_MB;
};

struct request_queue
{
	int T_flag;
	int App_type;
	int App_no;
	int req_no;
	int ope;
	int phase;
	long long req_size;

	unsigned long long read_start;
	unsigned long long write_start;
	unsigned long long response_time;
};

struct waiting_queue
{
	int flag;  //done?
	int T_flag;
	int App_type;
	int App_no;
	int req_no;
	int ope;
	int phase;
	long long req_size;

	struct waiting_queue* next;
};

void ssd_sim(struct data_node* node);
struct request_queue* get_ssd_request(struct request_queue* req, struct waiting_queue* queue);
void ssd_process(struct ssd* ssd);
unsigned long long garbage_collection(struct ssd* ssd, unsigned long long process_time);
void ssd_set_time(struct ssd* ssd, struct data_node* node);
void clear_ssd_queue(struct ssd* ssd);
struct waiting_queue* remove_wq(struct request_queue* req, struct waiting_queue* queue);