#define _CRTDBG_MAP_ALLOC
#define _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES 1

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <stdbool.h>
#include <crtdbg.h>
#include <math.h>

#include "main.h"
#include "host.h"
#include "core.h"
#include "ssd.h"
#include "transfer.h"
#include "initial.h"

unsigned long long TIMETICK = 0;
int input_count = 0;
int req_count = 1;
int Activate = TRUE;
int reduce_collection[QUEUE_SIZE] = { 0 };  //for trace

int main()
{
	printf("SIMULATION START.....!\n\n\n");
	int rack, node;
	initialize();
	Namenode = namenode_operation(Namenode);
	
	int i, j;
	struct sub_task* sub;
	struct Input* input;
	struct task_queue* task;
	struct cpu* cpu;
	struct waiting_queue* queue;
	struct request_queue* req;
	struct transfer_cluster* cluster;

	struct node_info* info;
	for (i = 0; i < TOTAL_RACK; i++)
	{
		for (j = 0; j < TOTAL_NODE; j++)
		{
			info = Namenode->info[i]->info[j];
			printf("rack: %d node: %d total map task: %lld total reduce task: %lld\n", i, j, info->total_map_task_in_node, info->total_red_task_in_ndoe);
			
		}
	}

#ifdef DEBUG
	input = Namenode->head;
	while (input != NULL)
	{
		sub = input->sub;
		while (sub != NULL)
		{
			printf("req: %d rack: %d node: %d dep: %d rt: %d\n", sub->req_no, sub->rack_id, sub->node_id, sub->dep_task_no, sub->rt_total);
			sub = sub->next;
		}
		input = input->next;
	}
#endif // DEBUG

	while (TIMETICK >= 0)
	{
		Namenode = fetch_tranfer(Namenode);  //fetch transfer
		Namenode = transfer_timer(Namenode);  //transfer timer(release ssd stat)
		transfer_process(CLUSTER);  

		for (rack = 0; rack < TOTAL_RACK; rack++)
		{
			for (node = 0; node < TOTAL_NODE; node++)
			{
				task_presetting(Namenode->rack[rack]->data_node[node]);  //task presetting
				task_execution(Namenode->rack[rack]->data_node[node]); //task execution
			}
		}

		Namenode->head = conclude(Namenode->head);  //task conclude
		Activate = Activate_check(Namenode);
		if (Activate == FALSE) break;
		TIMETICK++;
	}
	
	/******************************************************************************************/

	printf("\n\n");
	input = Namenode->head;
	while (input != NULL)
	{
		printf("App NO: %d App: %d Prio: %d start: %llu end: %llu Resp: %llu Read: %.2f Write: %.2f map: %llu red: %llu\n", input->App_no, input->App_type, input->priority, input->start_time, input->end_time, input->end_time - input->start_time, input->Read_SLO, input->Write_SLO, input->map_phase_resp, input->reduce_phase_resp);
		
		input = input->next;
	}
	
	printf("\n\nSIMULATION DONE.....!\n");
	system("pause");
}

int Activate_check(struct name_node* namenode)
{
	int flag = FALSE;
	struct Input* input;
	input = namenode->head;
	while (input != NULL)
	{
		if (input->job_flag == TRUE) flag = TRUE;
		input = input->next;
	}

	return flag;
}

struct name_node* fetch_tranfer(struct name_node* namenode)
{
	struct Input* temp;
	temp = namenode->head;
	struct sub_task* sub;
	struct task_queue* task;
	int i, j, relation = Remote, relation_compare = Remote, rack_id = NOSET, rack_id_compare = NOSET;

	while (temp != NULL)
	{
		sub = temp->sub;
		while (sub != NULL)
		{
			if (sub->flag == FALSE && sub->phase == MAP)
			{
				relation = Remote;
				relation_compare = Remote;
				rack_id = NOSET;
				rack_id_compare = NOSET;
				for (i = 0; i < TOTAL_RACK; i++)
				{
					for (j = 0; j < TOTAL_NODE; j++)
					{
						task = namenode->rack[i]->data_node[j]->queue;
						relation_compare = relation_check(task, sub, &rack_id_compare);
						if (relation_compare < relation)
						{
							relation = relation_compare;
							rack_id = rack_id_compare;
						}
					}
				}
				
				get_transfer(CLUSTER, relation, rack_id, sub->req_no, sub->priority, sub->rt_total, sub->dep_task_no, REDUCE);  //add local or remote
				sub->flag = COMPLETE;
			}
			sub = sub->next;
		}
		temp = temp->next;
	}

	return namenode;
}

int relation_check(struct task_queue* task, struct sub_task* sub, int* rack_id)
{
	int relation = Remote;
	struct task_queue* temp;
	temp = task;

	while (temp != NULL)
	{
		if (temp->App_no == sub->App_no && temp->req_no == sub->dep_task_no)
		{
			*rack_id = temp->rack_id;
			if (temp->rack_id == sub->rack_id)
			{
				if (temp->node_id == sub->node_id)
				{
					return Local;
				}
				else
				{
					return Rack_local;
				}
			}
			else
			{
				return Remote;
			}
			
		}
		temp = temp->next;
	}

	
}

struct Input* conclude(struct Input* input)
{
	struct Input* temp;
	temp = input;
	struct sub_task* sub;
	int count;
	unsigned long long start, end, read_s, read_e, write_s, write_e, map_s, red_s, map_e, red_e;

	while (temp != NULL)
	{
		count = 0;
		start = 1000000000;
		end = 0;
		read_s = 1000000000;
		read_e = 0;
		write_s = 1000000000;
		write_e = 0;
		map_s = 1000000000;
		map_e = 0;
		red_s = 1000000000;
		red_e = 0;
		if (temp->job_flag == TRUE)
		{
			sub = temp->sub;
			while (sub != NULL)
			{
				if (sub->phase == REDUCE && sub->flag == FALSE) count++;
				sub = sub->next;
			}
			if (count == temp->total_reduce_task)
			{
				temp->job_flag = FALSE;
				sub = temp->sub;
				while (sub != NULL)
				{
					if (sub->task_start_time <= start) start = sub->task_start_time;
					if (sub->task_end_time >= end) end = sub->task_end_time;

					if (sub->read_start <= read_s) read_s = sub->read_start;
					if (sub->read_end >= read_e) read_e = sub->read_end;

					if (sub->write_start <= write_s) write_s = sub->write_start;
					if (sub->write_end >= write_e) write_e = sub->write_end;

					if (sub->phase == MAP && sub->read_start <= map_s) map_s = sub->read_start;
					if (sub->phase == MAP && sub->write_end >= map_e) map_e = sub->write_end;

					if (sub->phase == REDUCE && sub->read_start <= red_s) red_s = sub->read_start;
					if (sub->phase == REDUCE && sub->write_end >= red_e) red_e = sub->write_end;
					sub = sub->next;
				}
				temp->start_time = start;
				temp->end_time = end;
				temp->read_resp = read_e - read_s;
				temp->write_resp = write_e - write_s;
				temp->map_phase_resp = map_e - map_s;
				temp->reduce_phase_resp = red_e - red_s;
				SLO_estimation(&temp->Read_SLO, &temp->Write_SLO, temp);  //SLO count
			}
		}
		temp = temp->next;
	}
	return input;
}

void SLO_estimation(double* R_SLO, double* W_SLO, struct Input* input)
{
	long long Total_R_size = 0, Total_W_size = 0;
	unsigned long long R_resp = 0, W_resp = 0;
	unsigned long multiple = pow(10, 3);

	if (input->App_type == GREP || input->App_type == TERASORT)
	{
		Total_R_size = input->total_map_task * block_size + input->total_reduce_task * block_size;
		Total_W_size = input->total_map_task * block_size + input->total_reduce_task * block_size;
	}
	else if (input->App_type == WC)
	{
		Total_R_size = input->total_map_task * block_size + input->total_reduce_task * ceil(block_size * WCratio);
		Total_W_size = input->total_map_task * ceil(block_size * WCratio) + input->total_reduce_task * ceil(block_size * WCratio);
	}
	else if (input->App_type == DFSIO)
	{
		Total_R_size = input->total_map_task * block_size + input->total_reduce_task * ceil(block_size * DFSIOratio);
		Total_W_size = input->total_map_task * ceil(block_size * DFSIOratio) + input->total_reduce_task * ceil(block_size * DFSIOratio * DFSIOratio);
	}
	
	R_resp = input->read_resp / multiple;
	W_resp = input->write_resp / multiple;

	//printf("read size: %lld write size: %lld read_time: %llu write time: %llu\n", Total_R_size, Total_W_size, R_resp, W_resp);

	*R_SLO = (double)Total_R_size / (double)R_resp;
	*W_SLO = (double)Total_W_size / (double)W_resp;

}

struct admission_control* admission_control_estimation(struct admission_control* ac, int total_app)
{
	int i, j, routine;
	struct admission_control* temp;
	unsigned long multiple_6 = pow(10, 6); // ns -> ms
	unsigned long multiple_3 = pow(10, 3); // 
	long long M_time[1000][(TOTAL_NODE * TOTAL_RACK) + 1] = { 0 };
	long long R_time[1000][(TOTAL_NODE * TOTAL_RACK) + 1] = { 0 };
	unsigned long long t_ssdmapr = 0, t_ssdmapw = 0, t_ssdredr = 0, t_ssdredw = 0, map_exe = 5000, red_exe = 1000, t_BM = 0, t_BR = 0, T_MAP = 0, T_RED = 0, t_Dm = 0, t_Dr = 0;
	unsigned long long previous_map = 0, previous_red = 0, t_gc = 0, transfer = 0, local = 0;
	long long mapping_precount = 0, local_transfer_precount = 0, mapping_diff = 0, mapping_cover = 0;
	//estimate own map time and reduce time
	temp = ac;
	while (temp != NULL)
	{
		mapping_precount = 0;
		local_transfer_precount = 0;
		mapping_diff = 0;
		mapping_cover = 0;
		t_Dm = 0;
		if (temp->App_type == TERASORT || temp->App_type == GREP)
		{
			t_ssdmapr = (((unsigned long long)block_size * 256 * 122575) / 2) / multiple_6;
			t_ssdmapw = (((unsigned long long)block_size * 256 * 302575) / 2) / multiple_6;
			t_ssdredr = t_ssdmapr;
			t_ssdredw = t_ssdmapw;

			local_transfer_precount = (((double)ceil((unsigned long long)block_size) / (double)TRANS->N_to_N) * multiple_3);
			local = /*(((double)ceil((unsigned long long)block_size) / (double)TRANS->N_to_N) * multiple_3) +*/ ((((unsigned long long)block_size * 256 * 302575) / 2) / multiple_6);
			transfer = ((double)ceil((unsigned long long)block_size) / (double)TRANS->R_to_R) * multiple_3;
		}
		else if (temp->App_type == WC)
		{
			t_ssdmapr = (((unsigned long long)block_size * 256 * 122575) / 2) / multiple_6;
			t_ssdmapw = ((ceil((unsigned long long)block_size * WCratio) * 256 * 302575) / 2) / multiple_6;
			t_ssdredr = ((ceil((unsigned long long)block_size * WCratio) * 256 * 122575) / 2) / multiple_6;
			t_ssdredw = t_ssdmapw;

			local_transfer_precount = (((double)ceil((unsigned long long)block_size) / (double)TRANS->N_to_N) * multiple_3);
			local = /*(((double)ceil((unsigned long long)block_size * WCratio) / (double)TRANS->N_to_N) * multiple_3) +*/ ((((unsigned long long)block_size * 256 * 302575) / 2) / multiple_6);
			transfer = ((double)ceil((unsigned long long)block_size * WCratio) / (double)TRANS->R_to_R) * multiple_3;
		}
		else if (temp->App_type == DFSIO)
		{
			t_ssdmapr = (((unsigned long long)block_size * 256 * 122575) / 2) / multiple_6;
			t_ssdmapw = ((ceil((unsigned long long)block_size * DFSIOratio) * 256 * 302575) / 2) / multiple_6;
			t_ssdredr = ((ceil((unsigned long long)block_size * DFSIOratio) * 256 * 122575) / 2) / multiple_6;
			t_ssdredw = ((ceil((unsigned long long)block_size * DFSIOratio * DFSIOratio) * 256 * 302575) / 2) / multiple_6;

			local_transfer_precount = (((double)ceil((unsigned long long)block_size) / (double)TRANS->N_to_N) * multiple_3);
			local = ((((unsigned long long)block_size * 256 * 302575) / 2) / multiple_6);
			transfer = ((double)ceil((unsigned long long)block_size * DFSIOratio) / (double)TRANS->R_to_R) * multiple_3;
		
		}
		
		t_BM = (((unsigned long long)block_size * 256 * 302575) / 2) / multiple_6;
		t_BR = (t_ssdredr > red_exe) ? (t_BM + (t_ssdredr - red_exe)) : t_BM;
		temp->Map_per_task = t_ssdmapr + map_exe + t_ssdmapw;
		temp->Red_per_task = t_ssdredr + red_exe + t_ssdredw;
		temp->Mssd_r = t_ssdmapr;
		temp->Mssd_w = t_ssdmapw;
		temp->Rssd_r = t_ssdredr;
		temp->Rssd_w = t_ssdredw;

		if (MODE->memory_exist == FALSE) t_Dm += temp->total_map_task * local;
		
		for (i = 1; i <= TOTAL_RACK * TOTAL_NODE; i++)
		{
			if (temp->App_type == TERASORT || temp->App_type == GREP)
			{
				T_MAP = ceil(ceil((double)temp->total_map_task / (double)i) / TOTAL_CORE) * temp->Map_per_task + floor(ceil((double)temp->total_map_task / (double)i) / TOTAL_CORE) * t_BM + t_Dm;
			}
			else if (temp->App_type == WC)
			{
				T_MAP = ceil(ceil((double)temp->total_map_task / (double)i) / TOTAL_CORE) * temp->Map_per_task + t_BM;
			}
			else if (temp->App_type == DFSIO)
			{
				mapping_precount = ceil(ceil((double)temp->total_map_task / (double)i) / TOTAL_CORE) * temp->Map_per_task + floor(ceil((double)temp->total_map_task / (double)i) / TOTAL_CORE) * t_BM + t_Dm;
				mapping_cover = ceil(mapping_precount / local_transfer_precount);
				mapping_diff = temp->total_map_task - ceil(mapping_precount / local_transfer_precount);
				
				if (mapping_cover < temp->total_map_task) t_Dm = mapping_diff * local_transfer_precount;

				T_MAP = ceil(ceil((double)temp->total_map_task / (double)i) / TOTAL_CORE) * temp->Map_per_task + floor(ceil((double)temp->total_map_task / (double)i) / TOTAL_CORE) * t_BM + t_Dm;
			}

			if (temp->total_map_task % i == 0)t_Dr = ceil((double)i / (double)TOTAL_RACK) * transfer;
			else if (temp->total_map_task % i > 0 && temp->total_map_task % i < i / TOTAL_RACK)t_Dr = (temp->total_map_task % i) * transfer;
			else if (temp->total_map_task % i > 0 && temp->total_map_task % i > i / TOTAL_RACK)t_Dr = ceil((double)i / (double)TOTAL_RACK) * transfer;
			T_RED = ceil(ceil((double)temp->total_reduce_task / (double)i) / TOTAL_CORE) * temp->Red_per_task + floor(ceil((double)temp->total_reduce_task / (double)i) / TOTAL_CORE) * t_BR + t_Dr;

			temp->MAP_time[i] = T_MAP;
			temp->RED_time[i] = T_RED;

			M_time[temp->prio][i] = T_MAP;
			R_time[temp->prio][i] = T_RED;
		}

		temp = temp->next;
	}

	for (i = 1; i < (TOTAL_NODE * TOTAL_RACK) + 1; i++)
	{
		long long total_size = (2 * 4 * 2 * 2 * 2048 * 64 * 4) / 1024;
		long long threshold = total_size * MODE->gc_threshold;
		long long budget = total_size * MODE->ssd_budget_ratio;

		for (routine = 1; routine <= total_app; routine++)
		{
			temp = ac;
			while (temp != NULL)
			{
				if (temp->prio == routine)
				{
					long long max_wcount = 0;
					t_gc = 0;

					if (temp->App_type == WC)
					{
						max_wcount = ceil((double)temp->total_map_task / (double)i) * ceil((unsigned long long)block_size * WCratio) + ceil((double)temp->total_reduce_task / (double)i) * ceil((unsigned long long)block_size * WCratio);

						if (budget - max_wcount > 0)
						{
							budget -= max_wcount;
							if (budget < threshold)
							{
								t_gc = 384 * ceil((double)(threshold - budget) / (double)block_size);
								budget += ceil((double)(threshold - budget) / (double)block_size) * block_size;
							}
						}
						else
						{
							t_gc = 384 * ceil((double)(max_wcount - (budget - threshold)) / (double)block_size);
							budget = total_size * MODE->ssd_budget_ratio;
						}
					}
					else if (temp->App_type == TERASORT || temp->App_type == GREP)
					{
						max_wcount = ceil((double)temp->total_map_task / (double)i) * ceil((unsigned long long)block_size) + ceil((double)temp->total_reduce_task / (double)i) * ceil((unsigned long long)block_size);
						if (budget - max_wcount > 0)
						{
							budget -= max_wcount;
							if (budget < threshold)
							{
								t_gc = 384 * ceil((double)(threshold - budget) / (double)block_size);
								budget += ceil((double)(threshold - budget) / (double)block_size) * block_size;
							}
						}
						else
						{
							t_gc = 384 * ceil((double)(max_wcount - (budget - threshold)) / (double)block_size);
							budget = total_size * MODE->ssd_budget_ratio;
						}
					}
					else if (temp->App_type == DFSIO)
					{
						max_wcount = ceil((double)temp->total_map_task / (double)i) * ceil((unsigned long long)block_size * DFSIOratio) + ceil((double)temp->total_reduce_task / (double)i) * ceil((unsigned long long)block_size * DFSIOratio * DFSIOratio);
						if (budget - max_wcount > 0)
						{
							budget -= max_wcount;
							if (budget < threshold)
							{
								t_gc = 384 * ceil((double)(threshold - budget) / (double)block_size);
								budget += ceil((double)(threshold - budget) / (double)block_size) * block_size;
							}
						}
						else
						{
							t_gc = 384 * ceil((double)(max_wcount - (budget - threshold)) / (double)block_size);
							budget = total_size * MODE->ssd_budget_ratio;
						}
					}

					temp->t_gc[i] = t_gc;  //update t_gc
				}
				temp = temp->next;
			}
		}
	}


	//add all possible time estimate SLO
	for (routine = 1; routine <= total_app; routine++)
	{
		temp = ac;
		while (temp != NULL)
		{
			if (temp->prio == routine)
			{
				for (i = 1; i < (TOTAL_NODE * TOTAL_RACK) + 1; i++)
				{
					previous_map = 0;
					previous_red = 0;
					for (j = 0; j < routine; j++)
					{
						previous_map += M_time[j][i];
						previous_red += R_time[j][i];
					}
					temp->resp_time[i] = temp->MAP_time[i] + temp->RED_time[i] + previous_map + previous_red + M_time[temp->prio + 1][i] + temp->t_gc[i];  

					temp->read_resp[i] = temp->resp_time[i] - temp->Red_per_task + temp->Rssd_r;
					temp->write_resp[i] = temp->resp_time[i] - temp->Map_per_task + temp->Mssd_w;
					temp->read_resp[i] = temp->read_resp[i] / multiple_3;
					temp->write_resp[i] = temp->write_resp[i] / multiple_3;

					temp->predicted_Read_SLO[i] = (double)temp->read_size / (double)temp->read_resp[i];
					temp->predicted_Write_SLO[i] = (double)temp->write_size / (double)temp->write_resp[i];
					//printf("%llu %llu %llu %llu %llu %llu\n", temp->MAP_time[i], temp->RED_time[i], previous_map, previous_red, M_time[temp->prio + 1][i], temp->t_gc[i]);
					if (i%2 == 0) printf("Node: %d App: %d Time: %llu SLO_R: %.2f SLO_W: %.2f r_size: %lld w_size: %lld\n", i, temp->App_type, temp->resp_time[i], temp->predicted_Read_SLO[i], temp->predicted_Write_SLO[i], temp->read_size, temp->write_size);
				}
				printf("\n");
			}
			
			temp = temp->next;
		}
	}
	
	

	return ac;
}