#define _CRTDBG_MAP_ALLOC
#define _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES 1

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <stdbool.h>
#include <crtdbg.h>
#include <math.h>

#include "main.h"
#include "host.h"
#include "core.h"
#include "ssd.h"
#include "transfer.h"
#include "initial.h"

extern unsigned long long TIMETICK;
extern int input_count;
extern int req_count;


void initialize()
{
	int i;
	Namenode = (struct name_node*)malloc(sizeof(struct name_node));

	load_mode();  //get mode
	load_input(Namenode); //get input
	load_locality();  //get locality
	split_task(Namenode);  //create sub task
	load_dependency(Namenode);  //get dependency

	for (i = 0; i < TOTAL_RACK; i++) Namenode->rack[i] = initial_rack(Namenode->rack[i], i);  //initialize all node, rack
	for (i = 0; i < TOTAL_RACK; i++) Namenode->info[i] = initial_rack_info(Namenode->info[i], i, Namenode);
	CLUSTER = initial_transfer_cluster(CLUSTER);  //initialize transfer
}

void initial_ac(struct name_node* namenode)
{
	int i, j;
	struct Input* input;
	input = namenode->head;

	namenode->ac = NULL;
	namenode->current_ac = NULL;
	namenode->prev_ac = NULL;

	while (input != NULL)
	{
		namenode->current_ac = (struct admission_control*)malloc(sizeof(struct admission_control));

		namenode->current_ac->App_no = input->App_no;
		namenode->current_ac->App_type = input->App_type;
		namenode->current_ac->total_size = input->total_size;
		namenode->current_ac->prio = input->priority;
		namenode->current_ac->total_map_task = input->total_map_task;
		namenode->current_ac->total_reduce_task = input->total_reduce_task;

		if (namenode->current_ac->App_type == TERASORT || namenode->current_ac->App_type == GREP)
		{
			namenode->current_ac->read_size = namenode->current_ac->total_map_task * (unsigned long long)block_size + namenode->current_ac->total_reduce_task * (unsigned long long)block_size;
			namenode->current_ac->write_size = namenode->current_ac->read_size;
		}
		else if (namenode->current_ac->App_type == WC)
		{
			namenode->current_ac->read_size = namenode->current_ac->total_map_task * (unsigned long long)block_size + namenode->current_ac->total_reduce_task * ceil(WCratio * (unsigned long long)block_size);
			namenode->current_ac->write_size = namenode->current_ac->total_map_task * ceil(WCratio * (unsigned long long)block_size) + namenode->current_ac->total_reduce_task * ceil(WCratio * (unsigned long long)block_size);
		}
		else if (namenode->current_ac->App_type == DFSIO)
		{
			namenode->current_ac->read_size = namenode->current_ac->total_map_task * (unsigned long long)block_size + namenode->current_ac->total_reduce_task * ceil(DFSIOratio * (unsigned long long)block_size);
			namenode->current_ac->write_size = namenode->current_ac->total_map_task * ceil(DFSIOratio * (unsigned long long)block_size) + namenode->current_ac->total_reduce_task * ceil(DFSIOratio * DFSIOratio * (unsigned long long)block_size);
		}

		namenode->current_ac->start = 0;
		namenode->current_ac->end = 0;
		
		for (i = 0; i < (TOTAL_NODE * TOTAL_RACK) + 1; i++)
		{
			namenode->current_ac->predicted_Read_SLO[i] = 0;
			namenode->current_ac->predicted_Write_SLO[i] = 0;
			namenode->current_ac->MAP_time[i] = 0;
			namenode->current_ac->RED_time[i] = 0;
			namenode->current_ac->read_resp[i] = 0;
			namenode->current_ac->write_resp[i] = 0;
			namenode->current_ac->resp_time[i] = 0;
			namenode->current_ac->t_gc[i] = 0;
		}		

		namenode->current_ac->Map_per_task = 0;
		namenode->current_ac->Red_per_task = 0;
		namenode->current_ac->node_needed = 10000;
		namenode->current_ac->next = NULL;

		if (namenode->ac == NULL) namenode->ac = namenode->current_ac;
		else namenode->prev_ac->next = namenode->current_ac;
		namenode->prev_ac = namenode->current_ac;

		input = input->next;
	}
}

struct Node_to_Node* initial_Node_to_Node(struct Node_to_Node* N_N, int id)
{
	int i;
	N_N = (struct Node_to_Node*)malloc(sizeof(struct Node_to_Node));
	N_N->rack_id = id;
	N_N->t_queue = NULL;
	N_N->list = NULL;
	N_N->prev = NULL;
	N_N->current - NULL;
	N_N->count = 0;
	N_N->current_req = NOSET;
	N_N->current_time = 0;
	N_N->stat = IDLE;
	N_N->total_req = 0;
	for (i = 0; i < QUEUE_SIZE; i++)
	{
		N_N->queue[i] = 0;
		N_N->record_prio[i] = 0;
		N_N->record_rt[i] = 0;
		N_N->record_dep_task[i] = 0;
	}

	return N_N;
}

struct Rack_to_Rack* initial_Rack_to_Rack(struct Rack_to_Rack* R_R)
{
	int i;
	R_R = (struct Rack_to_Rack*)malloc(sizeof(struct Rack_to_Rack));
	R_R->t_queue = NULL;
	R_R->list = NULL;
	R_R->prev = NULL;
	R_R->current = NULL;
	R_R->count = 0;
	R_R->current_req = NOSET;
	R_R->current_time = 0;
	R_R->stat = IDLE;
	R_R->total_req = 0;
	for (i = 0; i < QUEUE_SIZE; i++)
	{
		R_R->queue[i] = 0;
		R_R->record_prio[i] = 0;
		R_R->record_rt[i] = 0;
		R_R->record_dep_task[i] = 0;
	}

	return R_R;
}

struct transfer_cluster* initial_transfer_cluster(struct transfer_cluster* cluster)
{
	int i;
	cluster = (struct transfer_cluster*)malloc(sizeof(struct transfer_cluster));
	cluster->R_R = initial_Rack_to_Rack(cluster->R_R);
	for (i = 0; i < TOTAL_RACK; i++) cluster->N_N[i] = initial_Node_to_Node(cluster->N_N[i], i);

	return cluster;
}

struct node_info* initial_node_info(struct node_info* info, int id, int rack_id, struct name_node* namenode)
{
	info = (struct node_info*)malloc(sizeof(struct node_info));
	int i;
	info->node_id = id;
	info->total_map_task_in_node = 0;
	info->total_red_task_in_ndoe = 0;
	info->total_map_task = 0;
	info->total_reduce_task = 0;
	info->total_task_in_node = 0;
	info->waiting_time = 0;
	info->exe_slot = 0;
	for (i = 0; i < TOTAL_CORE; i++) info->waiting_time_keep[i] = 0;
	
	info->gc_threshold_estimation = Namenode->rack[rack_id]->data_node[id]->ssd->gc_threshold;
	info->gc_overprovision_estimation = Namenode->rack[rack_id]->data_node[id]->ssd->over_provision;
	info->gc_count = 0;

	struct Input* temp;
	temp = namenode->head;
	while (temp != NULL)
	{
		info->total_map_task += temp->total_map_task;
		info->total_reduce_task += temp->total_reduce_task;
		temp = temp->next;
	}
	
	return info;
}

struct rack_info* initial_rack_info(struct rack_info* info, int id, struct name_node* namenode)
{
	int i, j;
	info = (struct rack_info*)malloc(sizeof(struct rack_info));

	info->total_map_task = 0;
	info->total_reduce_task = 0;
	info->rack_id = id;
	info->total_task_in_rack = 0;
	for (i = 0; i < TOTAL_NODE; i++) info->info[i] = initial_node_info(info->info[i], i, info->rack_id, namenode);
	for (i = 0; i < QUEUE_SIZE; i++)
	{
		for (j = 0; j < TOTAL_NODE; j++)
		{
			info->transfer_size[i][j] = 0;
			info->dep_req_no[i][j] = 0;
		}
	}

	struct Input* temp;
	temp = namenode->head;
	while (temp != NULL)
	{
		info->total_map_task += temp->total_map_task;
		info->total_reduce_task += temp->total_reduce_task;
		temp = temp->next;
	}
	
	return info;
}

struct parameter* initial_parameter(struct parameter* para)
{
	para = (struct parameter*)malloc(sizeof(struct parameter));

	FILE* fp;
	errno_t err;
	char buf[300];
	char* ptr;
	int pre_eql, next_eql;
	int res_eql;

	if ((err = fopen_s(&fp, "./file/parameter.txt", "r")) != 0) printf("the file Input error!\n");

	while (fgets(buf, 300, fp))
	{
		ptr = strchr(buf, '=');
		if (!ptr) continue;

		pre_eql = ptr - buf;
		next_eql = pre_eql + 1;

		while (buf[pre_eql - 1] == ' ') pre_eql--;
		buf[pre_eql] = 0;

		if ((res_eql = strcmp(buf, "tPROG")) == 0) sscanf(buf + next_eql, "%llu", &para->tPROG);
		else if ((res_eql = strcmp(buf, "tBERS")) == 0) sscanf(buf + next_eql, "%llu", &para->tBERS);
		else if ((res_eql = strcmp(buf, "tWC")) == 0) sscanf(buf + next_eql, "%llu", &para->tWC);
		else if ((res_eql = strcmp(buf, "tR")) == 0) sscanf(buf + next_eql, "%llu", &para->tR);
		else if ((res_eql = strcmp(buf, "tRC")) == 0) sscanf(buf + next_eql, "%llu", &para->tRC);
		else if ((res_eql = strcmp(buf, "tWB")) == 0) sscanf(buf + next_eql, "%llu", &para->tWB);
		else if ((res_eql = strcmp(buf, "channel")) == 0) sscanf(buf + next_eql, "%llu", &para->channel);
		else if ((res_eql = strcmp(buf, "chip")) == 0) sscanf(buf + next_eql, "%llu", &para->chip);
		else if ((res_eql = strcmp(buf, "die")) == 0) sscanf(buf + next_eql, "%llu", &para->die);
		else if ((res_eql = strcmp(buf, "plane")) == 0) sscanf(buf + next_eql, "%llu", &para->plane);
		else if ((res_eql = strcmp(buf, "block")) == 0) sscanf(buf + next_eql, "%llu", &para->block);
		else if ((res_eql = strcmp(buf, "page")) == 0) sscanf(buf + next_eql, "%llu", &para->page);
		else if ((res_eql = strcmp(buf, "subpage")) == 0) sscanf(buf + next_eql, "%llu", &para->sub_page);
		else if ((res_eql = strcmp(buf, "subpage capacity")) == 0) sscanf(buf + next_eql, "%lld", &para->subpage_capacity);
		else if ((res_eql = strcmp(buf, "page capacity")) == 0) sscanf(buf + next_eql, "%lld", &para->page_capacity);
		else if ((res_eql = strcmp(buf, "sector capacity")) == 0) sscanf(buf + next_eql, "%lld", &para->sector_capacity);
		else if ((res_eql = strcmp(buf, "page per MB")) == 0) sscanf(buf + next_eql, "%lld", &para->page_MB);
		else if ((res_eql = strcmp(buf, "block per MB")) == 0) sscanf(buf + next_eql, "%lld", &para->block_MB);
		else printf("nothing match\t %s\n", buf);

	}
	
	fclose(fp);
	return para;
}

struct ssd* initial_ssd(struct ssd* ssd)
{
	ssd = (struct ssd*)malloc(sizeof(struct ssd));
	ssd->current_time = 0;
	ssd->gc_count = 0;
	ssd->ssd_stat = IDLE;
	ssd->req_q = NULL;
	ssd->read_q = NULL;
	ssd->read_current = NULL;
	ssd->read_prev = NULL;
	ssd->write_q = NULL;
	ssd->write_current = NULL;
	ssd->write_prev = NULL;
	ssd->para = initial_parameter(ssd->para);
	ssd->total_page = ssd->para->channel * ssd->para->chip * ssd->para->die * ssd->para->plane * ssd->para->block * ssd->para->page;
	ssd->over_provision = ceil(ssd->total_page * MODE->ssd_budget_ratio);
	ssd->gc_threshold = ceil(ssd->total_page * MODE->gc_threshold);
	//printf("total page: %lld  gc threshold: %lld budget: %lld\n", ssd->total_page, ssd->gc_threshold, ssd->over_provision);

	return ssd;
}

struct core* initial_core(struct core* core, int id)
{
	core = (struct core*)malloc(sizeof(struct core));
	core->core_id = id;
	core->core_stat = IDLE;
	core->current_time = 0;
	core->ope = NOSET;
	core->phase = NOSET;
	core->req_no = NOSET;
	core->start = 0;
	core->end = 0;

	return core;
}

struct cpu* initial_cpu(struct cpu* cpu)
{
	int i, j;
	cpu = (struct cpu*)malloc(sizeof(struct cpu));
	cpu->count = 0;
	cpu->location = 0;
	cpu->total_task = 0;
	for (i = 0; i < QUEUE_SIZE; i++)
	{
		cpu->Execution_queue[i] = 0;
		cpu->Ready_queue[i] = 0;
		cpu->Prio_keep[i] = 0;
		cpu->Prio_exe[i] = 0;
		cpu->Dep_keep[i] = 0;
		cpu->Dep_exe[i] = 0;
	}
	
	for (j = 0; j < TOTAL_CORE; j++) cpu->core[j] = initial_core(cpu->core[j], j);

	return cpu;
}

struct data_node* initial_node(struct data_node* node, int id)
{
	node = (struct data_node*)malloc(sizeof(struct data_node));
	node->node_id = id;
	node->queue = NULL;
	node->current = NULL;
	node->prev = NULL;
	node->cpu = initial_cpu(node->cpu);
	node->ssd = initial_ssd(node->ssd);

	return node;
}

struct rack* initial_rack(struct rack* rack, int id)
{
	int i;
	rack = (struct rack*)malloc(sizeof(struct rack));
	rack->rack_id = id;
	for (i = 0; i < TOTAL_NODE; i++) rack->data_node[i] = initial_node(rack->data_node[i], i);

	return rack;
}

void load_dependency(struct name_node* namenode)
{
	srand(time(NULL));
	struct sub_task* sub;
	struct Input* input;
	input = namenode->head;
	int red_req_list[QUEUE_SIZE] = { 0 };
	int i, key_count = 0, sort_num = 0, red_count = 0, max = 0, min = 0;

	FILE* fp;
	errno_t err;
	char buf[300];

	if (MODE->dependency_create_mode == TRUE)
	{
		if ((err = fopen_s(&fp, "./file/dep/dep_task_3_TERA.txt", "w")) != 0) printf("the file Input error!\n");
		while (input != NULL)
		{
			for (i = 0; i < QUEUE_SIZE; i++) red_req_list[i] = 0;
			red_count = 0;
			sort_num = 0;
			key_count = 0;
			sub = input->sub;
			while (sub != NULL)
			{
				if (sub->phase == REDUCE)
				{
					red_req_list[red_count] = sub->req_no;
					red_count++;
					printf("job: %d reduce task: %d\n", sub->App_type, sub->req_no);
				}
				sub = sub->next;
			}
			sub = input->sub;
			while (sub != NULL)
			{
				if (sub->phase == MAP)
				{
					max = red_req_list[red_count - 1];
					min = red_req_list[0];
					if (input->App_type == TERASORT)
					{
						sub->dep_task_no = red_req_list[sort_num];
						sort_num++;
						fprintf(fp, "%d\n", sub->dep_task_no);
					}
					else if (input->App_type == WC)
					{
						if (key_count < input->total_reduce_task)
						{
							sub->dep_task_no = red_req_list[key_count];
							key_count++;
						}
						else sub->dep_task_no = (rand() % (max - min + 1)) + min;
						fprintf(fp, "%d\n", sub->dep_task_no);
					}
					else if (input->App_type == GREP)
					{
						sub->dep_task_no =  (rand() % (max - min + 1)) + min;
						fprintf(fp, "%d\n", sub->dep_task_no);
					}
					else if (input->App_type == DFSIO)
					{
						sub->dep_task_no = red_req_list[sort_num];
						sort_num++;
						if (sort_num == input->total_map_task / 2) sort_num = 0;
						fprintf(fp, "%d\n", sub->dep_task_no);
					}
				}
				sub = sub->next;
			}
			input->sub = rt_dep_update(input->sub);  //update
			input = input->next;
		}
	}
	else
	{
		if ((err = fopen_s(&fp, "./file/dep/dep_task_3_TERA.txt", "r")) != 0) printf("the file Input error!\n");
		while (input != NULL)
		{
			sub = input->sub;
			while (sub != NULL)
			{
				if (sub->phase == MAP)
				{
					fgets(buf, 300, fp);
					sscanf_s(buf, "%d", &sub->dep_task_no);
				}
				sub = sub->next;
			}
			input->sub = rt_dep_update(input->sub);  //update
			input = input->next;
		}
	}

	fclose(fp);
}

struct sub_task* rt_dep_update(struct sub_task* sub)
{
	struct sub_task* temp;
	temp = sub;
	int record[QUEUE_SIZE][1] = { 0 };
	
	while (temp != NULL)
	{
		if (temp->phase == MAP) record[temp->dep_task_no][0]++;
		else if (temp->phase == REDUCE) temp->rt_total = record[temp->req_no][0];
		temp = temp->next;
	}
	temp = sub;
	while (temp != NULL)
	{
		if (temp->phase == MAP) temp->rt_total = record[temp->dep_task_no][0];
		temp = temp->next;
	}
	return sub;
}

void create_sub(struct Input* input, long long size, int phase)
{
	input->current = (struct sub_task*)malloc(sizeof(struct sub_task));

	input->current->flag = TRUE;
	input->current->rt_total = 0;
	input->current->dep_task_no = 0;
	input->current->req_no = req_count;
	req_count++;
	input->current->size = size;
	input->current->phase = phase;
	input->current->priority = NOSET;
	input->current->rack_id = NOSET;
	input->current->node_id = NOSET;
	input->current->App_no = input->App_no;
	input->current->App_type = input->App_type;

	input->current->task_start_time = 0;
	input->current->task_end_time = 0;
	input->current->read_start = 0;
	input->current->read_end = 0;
	input->current->write_start = 0;
	input->current->write_end = 0;

	input->current->next = NULL;

	if (input->sub == NULL) input->sub = input->current;
	else input->prev->next = input->current;
	input->prev = input->current;

}

void split_task(struct name_node* namenode)
{
	struct Input* temp;
	temp = namenode->head;

	int i, j;
	long long total_size = 0;

	while (temp != NULL)
	{
		temp->sub = NULL;
		temp->current = NULL;
		temp->prev = NULL;
		total_size = temp->total_size;
		
		for (i = 0; i < temp->total_map_task; i++)
		{
			if (total_size > 0)
			{
				if (total_size - block_size > 0) create_sub(temp, block_size, MAP);
				else create_sub(temp, total_size, MAP);

				total_size -= block_size;
			}
			
		}
		for (j = 0; j < temp->total_reduce_task; j++)
		{
			if (temp->App_type == WC) create_sub(temp, block_size, REDUCE);
			else if (temp->App_type == TERASORT) create_sub(temp, block_size, REDUCE);
			else if (temp->App_type == GREP) create_sub(temp, block_size, REDUCE);
			else if (temp->App_type == DFSIO) create_sub(temp, block_size, REDUCE);
		}

		temp = temp->next;
	}
}

int locality_gen_rack(int previous)
{
	int value;

	value = rand() % (TOTAL_RACK);
	if (value == previous) return locality_gen_rack(previous);
	else return value;
}

int locality_gen_node(int previous)
{
	int value;

	value = rand() % (TOTAL_NODE);
	if (value == previous) return locality_gen_node(previous);
	else return value;
}

void load_locality()
{
	srand(time(NULL));
	struct data_locality* data;
	data = (struct data_locality*)malloc(sizeof(struct data_locality));

	int i = 0, j = 0;
	FILE* fp;
	errno_t err;
	char buf[300];

	if (MODE->locality_create_mode == TRUE)
	{
		if ((err = fopen_s(&fp, "./file/locality_2_3.txt", "w")) != 0) printf("the file Input error!\n");
		
		for (j = 0; j < big_app_ratio; j++)
		{
			data->rack[j][0] = rand() % (TOTAL_RACK);
			data->node[j][0] = rand() % (TOTAL_NODE);
			data->rack[j][1] = data->rack[j][0];
			data->node[j][1] = locality_gen_node(data->node[j][0]);
			data->rack[j][2] = locality_gen_rack(data->rack[j][1]);
			data->node[j][2] = rand() % (TOTAL_NODE);
			fprintf(fp, "%d %d %d %d %d %d\n", data->rack[j][0], data->node[j][0], data->rack[j][1], data->node[j][1], data->rack[j][2], data->node[j][2]);
		}
	}
	else
	{
		if ((err = fopen_s(&fp, "./file/locality_2_3.txt", "r")) != 0) printf("the file Input error!\n");
		while (!feof(fp))
		{
			fgets(buf, 300, fp);
			sscanf_s(buf, "%d %d %d %d %d %d", &data->rack[i][0], &data->node[i][0], &data->rack[i][1], &data->node[i][1], &data->rack[i][2], &data->node[i][2]);
			i++;
		}
	}
	fclose(fp);

	DATA = data;
}

void load_input(struct name_node* namenode)
{
	namenode->head = NULL;
	namenode->current = NULL;
	namenode->prev = NULL;

	FILE* fp;
	errno_t err;
	char buf[300];
	long long total_size, total_map_task, total_reduce_task;
	double app_ratio = 0;

	if ((err = fopen_s(&fp, "./file/input/3_TERA.txt", "r")) != 0) printf("the file Input error!\n");

	while (!feof(fp))
	{
		namenode->current = (struct Input*)malloc(sizeof(struct Input));

		fgets(buf, 300, fp);
		sscanf_s(buf, "%lld %lld %lld", &total_size, &total_map_task, &total_reduce_task);

		namenode->current->total_size = total_size;
		namenode->current->total_map_task = total_map_task;
		namenode->current->total_reduce_task = total_reduce_task;

		app_ratio = (double)namenode->current->total_reduce_task / (double)namenode->current->total_map_task;

		if (app_ratio == TERASORTratio && namenode->current->total_size <= micron_app_max_size) namenode->current->App_type = TERASORT;
		else if (app_ratio < 0.35 && app_ratio >= WCratio) namenode->current->App_type = WC;
		else if (app_ratio < WCratio) namenode->current->App_type = GREP;
		else if (app_ratio == DFSIOratio && namenode->current->total_size > micron_app_max_size) namenode->current->App_type = DFSIO;

		input_count++;
		namenode->current->App_no = input_count;
		namenode->current->priority = NOSET;
		namenode->current->job_flag = TRUE;
		namenode->current->start_time = 0;
		namenode->current->end_time = 0;
		namenode->current->Read_SLO = 0;
		namenode->current->Write_SLO = 0;
		namenode->current->read_resp = 0;
		namenode->current->write_resp = 0;

		namenode->current->sub = NULL;
		namenode->current->next = NULL;

		if (namenode->head == NULL) namenode->head = namenode->current;
		else namenode->prev->next = namenode->current;
		namenode->prev = namenode->current;
	}

	fclose(fp);
}

void load_mode()
{
	struct mode* mode;
	mode = (struct mode*)malloc(sizeof(struct mode));
	struct transfer* trans;
	trans = (struct transfer*)malloc(sizeof(struct transfer));

	FILE* fp;
	errno_t err;
	char buf[300];
	char* ptr;
	int pre_eql, next_eql;
	int res_eql;

	if ((err = fopen_s(&fp, "./file/mode.txt", "r")) != 0) printf("the file Input error!\n");

	while (fgets(buf, 300, fp))
	{
		ptr = strchr(buf, '=');
		if (!ptr) continue;

		pre_eql = ptr - buf;
		next_eql = pre_eql + 1;

		while (buf[pre_eql - 1] == ' ') pre_eql--;
		buf[pre_eql] = 0;

		if ((res_eql = strcmp(buf, "structure")) == 0) sscanf(buf + next_eql, "%d", &mode->structure);
		else if ((res_eql = strcmp(buf, "scheduler")) == 0) sscanf(buf + next_eql, "%d", &mode->scheduler);
		else if ((res_eql = strcmp(buf, "memory")) == 0) sscanf(buf + next_eql, "%d", &mode->memory_exist);
		else if ((res_eql = strcmp(buf, "gc threshold")) == 0) sscanf(buf + next_eql, "%lf", &mode->gc_threshold);
		else if ((res_eql = strcmp(buf, "ssd budget ratio")) == 0) sscanf(buf + next_eql, "%lf", &mode->ssd_budget_ratio);
		else if ((res_eql = strcmp(buf, "locality create")) == 0) sscanf(buf + next_eql, "%d", &mode->locality_create_mode);
		else if ((res_eql = strcmp(buf, "dependency create")) == 0) sscanf(buf + next_eql, "%d", &mode->dependency_create_mode);
		else if ((res_eql = strcmp(buf, "N to N")) == 0) sscanf(buf + next_eql, "%llu", &trans->N_to_N);
		else if ((res_eql = strcmp(buf, "R to R")) == 0) sscanf(buf + next_eql, "%llu", &trans->R_to_R);
		else if ((res_eql = strcmp(buf, "MAP time")) == 0) sscanf(buf + next_eql, "%llu", &mode->map_time);
		else if ((res_eql = strcmp(buf, "REDUCE time")) == 0) sscanf(buf + next_eql, "%llu", &mode->reduce_time);
		else printf("nothing match\t %s\n", buf);

	}

	fclose(fp);

	MODE = mode;
	TRANS = trans;
}