#pragma once

#define BUSY 1

struct cpu
{
	int Execution_queue[QUEUE_SIZE];
	int Ready_queue[QUEUE_SIZE];
	int Prio_keep[QUEUE_SIZE];
	int Prio_exe[QUEUE_SIZE];
	int Dep_keep[QUEUE_SIZE];
	int Dep_exe[QUEUE_SIZE];
	int total_task;
	int count;
	int location;

	struct core* core[TOTAL_CORE];
};

struct core
{
	int core_id;
	int core_stat;

	int req_no;
	int ope;
	int phase;
	int App_type;
	int App_no;
	long long size;
	unsigned long long current_time;
	unsigned long long start;
	unsigned long long end;
};

void task_presetting(struct data_node* node);
int task_check(struct data_node* node);
int reduce_task_check(struct task_queue* task);
void task_schedule(struct data_node* node);
void workload_aware_scheduler(struct cpu* cpu, int num);
void task_execution(struct data_node* node);
void get_core(struct cpu* cpu, struct data_node* node, int id);
void fetch_ssd_req(struct data_node* node, struct core* core, int T_flag, int req);
void core_timer(struct data_node* node, struct core* core);
void ssd_timer(struct data_node* node);
unsigned long long core_process(struct task_queue* task);
void core_release(struct data_node* node, struct task_queue* task);
void task_update(struct task_queue* task, struct Input* input);
