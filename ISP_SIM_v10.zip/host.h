#pragma once

#define MAP 1111
#define REDUCE 2222

#define WC 1
#define TERASORT 2
#define GREP 3
#define DFSIO 4

#define WCratio 0.333333333
#define TERASORTratio 1
#define GREPratio 
#define DFSIOratio 0.5

#define micron_app_max_size 16384
#define micron_ratio 1050
#define big_app_ratio 4350

#include "initial.h"

struct name_node
{
	struct Input* head;
	struct Input* current;
	struct Input* prev;

	struct admission_control* ac;
	struct admission_control* current_ac;
	struct admission_control* prev_ac;

	struct rack* rack[TOTAL_RACK];
	struct rack_info* info[TOTAL_RACK];
}*Namenode;

struct Input
{
	int App_no;
	int App_type;
	int priority;
	int job_flag;  

	long long total_size;
	long long total_map_task;
	long long total_reduce_task;

	unsigned long long start_time;
	unsigned long long end_time;

	double Read_SLO;
	double Write_SLO;

	unsigned long long read_resp;
	unsigned long long write_resp;

	unsigned long long map_phase_resp;
	unsigned long long reduce_phase_resp;

	struct sub_task* sub;
	struct sub_task* current;
	struct sub_task* prev;
	struct Input* next;
};

struct sub_task
{
	int flag;
	int App_no;
	int App_type;
	int priority;
	int rt_total; //for scheduler dependcy

	int req_no;
	int dep_task_no;

	long long size;
	int phase;

	int rack_id;
	int node_id;

	unsigned long long read_start;
	unsigned long long read_end;
	unsigned long long write_start;
	unsigned long long write_end;

	unsigned long long task_start_time;
	unsigned long long task_end_time;

	struct sub_task* next;
};

struct rack
{
	int rack_id;

	struct data_node* data_node[TOTAL_NODE];
};

struct data_node
{
	int node_id;

	struct cpu* cpu;
	struct ssd* ssd;
	struct task_queue* queue;
	struct task_queue* current;
	struct task_queue* prev;
};

struct task_queue
{
	int req_no;
	int dep_task_no;
	int priority;
	int rt_total; //for scheduler dependcy
	
	int App_type;
	int App_no;
	int rack_id;
	int node_id;
	int ope;
	int phase; //MAP or REDUCE
	int task_stat;

	long long size;
	unsigned long long arrival_time;
	unsigned long long read_start;
	unsigned long long read_end;
	unsigned long long write_start;
	unsigned long long write_end;

	unsigned long long task_start_time;
	unsigned long long task_end_time;
	struct task_queue* next;
};

struct rack_info
{
	int rack_id;
	long long total_task_in_rack;
	long long total_map_task;
	long long total_reduce_task;

	int dep_req_no[QUEUE_SIZE][TOTAL_NODE];
	long long transfer_size[QUEUE_SIZE][TOTAL_NODE];

	struct node_info* info[TOTAL_NODE];
	//struct job_tracker* job_t;
};

struct node_info
{
	int node_id;

	unsigned long long waiting_time;
	long long total_task_in_node;
	long long total_map_task_in_node;
	long long total_red_task_in_ndoe;
	int exe_slot;
	unsigned long long waiting_time_keep[TOTAL_CORE];
	long long total_map_task;
	long long total_reduce_task;
	double gc_overprovision_estimation;
	double gc_threshold_estimation;
	int gc_count;
};

struct name_node* namenode_operation(struct name_node* namenode);
struct Input* priority_assignment(struct Input* input, int app_count);
struct Input* key_in_prio(struct Input* input);
struct Input* Dispatcher(struct Input* input);
void map_dispatcher(int* rack_id, int* node_id, struct sub_task* sub, struct Input* input);
void reduce_dispatcher(int* rack_id, int* node_id, struct sub_task* sub, struct Input* input);
struct rack_info* info_update(struct rack_info* info, struct sub_task* sub, unsigned long long task_time, int rack_id, int node_id);
unsigned long long task_time_estimation(unsigned long long task_time, struct sub_task* sub, int R_choice, int N_choice);
int locality_get(struct sub_task* sub, int R_choice, int N_choice);